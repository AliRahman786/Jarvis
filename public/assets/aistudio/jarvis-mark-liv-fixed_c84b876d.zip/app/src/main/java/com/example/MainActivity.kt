package com.example

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.content.pm.PackageManager
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.automation.JarvisAccessibilityService
import com.example.service.JarvisBackgroundService
import com.example.ui.screens.MainHudScreen
import com.example.ui.screens.SetupWizardScreen
import com.example.ui.theme.DarkHologramSurface
import com.example.ui.theme.DeepSpaceBlack
import com.example.ui.theme.HologramTextBright
import com.example.ui.theme.HologramTextDim
import com.example.ui.theme.HologramTextMuted
import com.example.ui.theme.HudCardSurface
import com.example.ui.theme.JarvisTheme
import com.example.ui.theme.SuccessEmerald
import com.example.viewmodel.JarvisViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        // Start background service only if runtime audio permission is already granted
        val hasMicPermission = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (hasMicPermission) {
            JarvisBackgroundService.start(this)
        }

        setContent {
            val viewModel: JarvisViewModel = viewModel()
            val isOnboardingCompleted by viewModel.prefs.onboardingCompletedFlow.collectAsState()
            val activePanel by viewModel.activePanel.collectAsState()
            val accentColor = viewModel.getAccentColor()
            val context = LocalContext.current

            var showBackgroundPermissionsModal by remember { mutableStateOf(false) }

            // PART 3: ONE-TIME PERMISSION ONBOARDING FLOW (Strictly on initial launch)
            val hasRequestedPermissions = viewModel.prefs.hasRequestedInitialPermissions()

            val permissionsLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) { results ->
                val micGranted = results[Manifest.permission.RECORD_AUDIO] == true ||
                    ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
                if (micGranted && viewModel.prefs.isBackgroundServiceEnabled()) {
                    JarvisBackgroundService.start(context)
                }

                // Check if background automation or accessibility permissions need user guidance once
                val accessibilityActive = JarvisAccessibilityService.isServiceEnabled(context)
                val overlayActive = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) Settings.canDrawOverlays(context) else true
                if (!accessibilityActive || !overlayActive) {
                    showBackgroundPermissionsModal = true
                }
                viewModel.prefs.setRequestedInitialPermissions(true)
            }

            LaunchedEffect(hasRequestedPermissions) {
                if (!hasRequestedPermissions) {
                    val permissions = mutableListOf(
                        Manifest.permission.RECORD_AUDIO,
                        Manifest.permission.CAMERA,
                        Manifest.permission.READ_CONTACTS,
                        Manifest.permission.CALL_PHONE
                    )
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        permissions.add(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    permissionsLauncher.launch(permissions.toTypedArray())
                }
            }

            // BackHandler for secondary panels -> return to HOME
            BackHandler(enabled = isOnboardingCompleted && activePanel != "HOME" && activePanel != "CORE") {
                viewModel.setActivePanel("HOME")
            }

            JarvisTheme(accentColor = accentColor) {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DeepSpaceBlack
                ) {
                    if (!isOnboardingCompleted) {
                        SetupWizardScreen(viewModel = viewModel)
                    } else {
                        MainHudScreen(viewModel = viewModel)
                    }

                    // Background Automation Guidance Dialog
                    if (showBackgroundPermissionsModal) {
                        BackgroundPermissionsModal(
                            accentColor = accentColor,
                            onDismiss = { showBackgroundPermissionsModal = false }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun BackgroundPermissionsModal(
    accentColor: Color,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = "System Security",
                    tint = accentColor,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "JARVIS BACKGROUND AUTOMATION",
                    color = accentColor,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "To enable hands-free screen reading, vision analysis, and auto-clicking in YouTube/WhatsApp, grant these Android 16 permissions:",
                    color = HologramTextDim,
                    fontSize = 10.sp,
                    fontFamily = FontFamily.Monospace
                )

                // Accessibility Service Action
                PermissionPromptCard(
                    title = "1. Accessibility Service",
                    desc = "Screen Vision capture & automated clicker",
                    accentColor = accentColor,
                    onClick = {
                        val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK
                        }
                        context.startActivity(intent)
                    }
                )

                // Display Over Other Apps Action
                PermissionPromptCard(
                    title = "2. Display Over Other Apps",
                    desc = "Persistent background voice receptor",
                    accentColor = accentColor,
                    onClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            val intent = Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:${context.packageName}")
                            ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
                            context.startActivity(intent)
                        }
                    }
                )

                // Battery Optimizations Action
                PermissionPromptCard(
                    title = "3. Disable Battery Saver",
                    desc = "Prevents OS from killing background listener",
                    accentColor = accentColor,
                    onClick = {
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                            val intent = Intent(
                                Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                                Uri.parse("package:${context.packageName}")
                            ).apply { flags = Intent.FLAG_ACTIVITY_NEW_TASK }
                            context.startActivity(intent)
                        }
                    }
                )
            }
        },
        confirmButton = {
            TextButton(
                onClick = onDismiss,
                modifier = Modifier.testTag("dismiss_permissions_modal")
            ) {
                Text("PROCEED TO CORE", color = accentColor, fontWeight = FontWeight.Bold)
            }
        },
        containerColor = DarkHologramSurface,
        tonalElevation = 8.dp
    )
}

@Composable
private fun PermissionPromptCard(
    title: String,
    desc: String,
    accentColor: Color,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(HudCardSurface)
            .border(1.dp, accentColor.copy(alpha = 0.35f), RoundedCornerShape(6.dp))
            .clickable { onClick() }
            .padding(8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                color = HologramTextBright,
                fontSize = 11.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Text(
                text = desc,
                color = HologramTextDim,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
        }
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(4.dp))
                .background(accentColor.copy(alpha = 0.2f))
                .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
            Text(
                text = "OPEN",
                color = accentColor,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
        }
    }
}
