package com.example.data.location

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import android.os.Build
import android.os.CancellationSignal
import android.provider.Settings
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import kotlin.coroutines.resume

data class LocationResult(
    val latitude: Double,
    val longitude: Double,
    val accuracyMeters: Float,
    val isPrecise: Boolean,
    val timestampMillis: Long,
    val provider: String
)

sealed class LocationStatus {
    data class Success(val result: LocationResult) : LocationStatus()
    data class PermissionDenied(val message: String) : LocationStatus()
    data class LocationServicesDisabled(val message: String) : LocationStatus()
    data class Error(val message: String) : LocationStatus()
}

/**
 * Foreground-only Device Location Manager.
 * Obtains fresh device location fix strictly on demand when user activates
 * Maps or Weather features. Respects precise vs approximate permission grants.
 * Never performs continuous background tracking.
 */
class DeviceLocationManager(private val context: Context) {

    private val locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
    private val executor = Executors.newSingleThreadExecutor()

    fun hasLocationPermission(): Boolean {
        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    fun hasPreciseLocationPermission(): Boolean {
        return ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    fun isLocationServiceEnabled(): Boolean {
        val lm = locationManager ?: return false
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lm.isLocationEnabled
        } else {
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        }
    }

    fun getLocationSettingsIntent(): Intent {
        return Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
    }

    suspend fun getCurrentLocation(maxStaleAgeMillis: Long = TimeUnit.MINUTES.toMillis(15)): LocationStatus = withContext(Dispatchers.IO) {
        if (!hasLocationPermission()) {
            return@withContext LocationStatus.PermissionDenied(
                "Location permission not granted. Current-location features require location permission."
            )
        }

        if (!isLocationServiceEnabled()) {
            return@withContext LocationStatus.LocationServicesDisabled(
                "Device location services are turned off. Please enable Location in Android settings."
            )
        }

        val isPrecise = hasPreciseLocationPermission()
        val lm = locationManager ?: return@withContext LocationStatus.Error("Location service unavailable.")

        // 1. Try fresh modern current-location request (API 30+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val freshFix = requestFreshCurrentLocationApi30(lm, isPrecise)
                if (freshFix != null) {
                    return@withContext LocationStatus.Success(
                        LocationResult(
                            latitude = freshFix.latitude,
                            longitude = freshFix.longitude,
                            accuracyMeters = freshFix.accuracy,
                            isPrecise = isPrecise,
                            timestampMillis = freshFix.time,
                            provider = freshFix.provider ?: "system"
                        )
                    )
                }
            } catch (_: Exception) {}
        }

        // 2. Fallback to cached location if fresh enough
        try {
            val providers = lm.getProviders(true)
            var bestLocation: Location? = null
            val now = System.currentTimeMillis()

            for (provider in providers) {
                @Suppress("MissingPermission")
                val loc = lm.getLastKnownLocation(provider) ?: continue
                val age = now - loc.time
                if (age <= maxStaleAgeMillis) {
                    if (bestLocation == null || loc.accuracy < bestLocation.accuracy) {
                        bestLocation = loc
                    }
                }
            }

            if (bestLocation != null) {
                return@withContext LocationStatus.Success(
                    LocationResult(
                        latitude = bestLocation.latitude,
                        longitude = bestLocation.longitude,
                        accuracyMeters = bestLocation.accuracy,
                        isPrecise = isPrecise,
                        timestampMillis = bestLocation.time,
                        provider = bestLocation.provider ?: "cache"
                    )
                )
            }
        } catch (_: Exception) {}

        LocationStatus.Error("Unable to acquire a fresh location fix. You can select your city manually.")
    }

    private suspend fun requestFreshCurrentLocationApi30(lm: LocationManager, isPrecise: Boolean): Location? =
        suspendCancellableCoroutine { continuation ->
            val cancellationSignal = CancellationSignal()
            continuation.invokeOnCancellation {
                cancellationSignal.cancel()
            }

            val provider = if (isPrecise && lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                LocationManager.GPS_PROVIDER
            } else if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                LocationManager.NETWORK_PROVIDER
            } else {
                LocationManager.PASSIVE_PROVIDER
            }

            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    @Suppress("MissingPermission")
                    lm.getCurrentLocation(
                        provider,
                        cancellationSignal,
                        executor
                    ) { location ->
                        if (continuation.isActive) {
                            continuation.resume(location)
                        }
                    }
                } else {
                    continuation.resume(null)
                }
            } catch (_: Exception) {
                if (continuation.isActive) {
                    continuation.resume(null)
                }
            }
        }
}
