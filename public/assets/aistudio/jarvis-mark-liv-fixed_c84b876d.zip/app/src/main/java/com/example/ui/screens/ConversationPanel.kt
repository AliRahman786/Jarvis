package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.ConversationEntity
import com.example.ui.hud.HudBadge
import com.example.ui.hud.HudPanel
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.HologramTextBright
import com.example.ui.theme.HologramTextDim
import com.example.ui.theme.HudCardSurface
import com.example.ui.theme.ReactorCyanGlow
import com.example.ui.theme.SuccessEmerald
import com.example.viewmodel.JarvisViewModel
import com.example.voice.VoiceState
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun ConversationPanel(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val messages by viewModel.conversationMessages.collectAsState()
    val inputText by viewModel.inputText.collectAsState()
    val voiceState by viewModel.voiceState.collectAsState()
    val accentColor = viewModel.getAccentColor()
    val listState = rememberLazyListState()
    val currentImageModel by viewModel.prefs.imageGenModelFlow.collectAsState()

    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    HudPanel(
        title = "TACTICAL COMMUNICATIONS & NEURAL TERMINAL",
        accentColor = accentColor,
        trailingBadge = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                HudBadge(text = "${messages.size} LOGS", color = accentColor)
                Spacer(modifier = Modifier.width(6.dp))
                IconButton(
                    onClick = { viewModel.clearConversationHistory() },
                    modifier = Modifier.size(28.dp).testTag("clear_history_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.DeleteSweep,
                        contentDescription = "Clear History",
                        tint = HologramTextDim,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        },
        modifier = modifier.fillMaxSize()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Message log
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (messages.isEmpty()) {
                    item {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 32.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = "COMMUNICATION LOG STANDBY",
                                    color = HologramTextDim,
                                    fontSize = 12.sp,
                                    fontFamily = FontFamily.Monospace,
                                    letterSpacing = 1.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Send commands, chat, or generate visuals using [$currentImageModel].",
                                    color = HologramTextDim,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
                items(messages, key = { it.id }) { msg ->
                    ConversationBubble(
                        message = msg,
                        accentColor = accentColor,
                        operatorName = viewModel.prefs.getUserName().uppercase(),
                        imageModelName = currentImageModel,
                        onSpeak = { viewModel.speakVoice(msg.content) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Input Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { viewModel.setInputText(it) },
                    placeholder = {
                        Text(
                            text = if (voiceState == VoiceState.LISTENING) "Listening..." else "Command or /image...",
                            color = HologramTextDim,
                            fontSize = 13.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field"),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = accentColor,
                        unfocusedBorderColor = accentColor.copy(alpha = 0.4f),
                        focusedTextColor = HologramTextBright,
                        unfocusedTextColor = HologramTextBright
                    ),
                    maxLines = 3
                )
                Spacer(modifier = Modifier.width(6.dp))

                // PART 4: Terminal-based Image Generation Trigger Button
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(accentColor.copy(alpha = 0.15f))
                        .border(1.dp, accentColor.copy(alpha = 0.6f), RoundedCornerShape(6.dp))
                        .clickable {
                            if (inputText.isNotBlank()) {
                                viewModel.generateTerminalImage(inputText)
                                viewModel.setInputText("")
                            } else {
                                viewModel.setInputText("Generate an image of ")
                            }
                        }
                        .testTag("image_gen_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = "Generate Image via $currentImageModel",
                        tint = accentColor,
                        modifier = Modifier.size(19.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Send Button
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(accentColor.copy(alpha = 0.2f))
                        .border(1.dp, accentColor, RoundedCornerShape(6.dp))
                        .clickable(enabled = inputText.isNotBlank()) {
                            viewModel.sendUserMessage(inputText)
                        }
                        .testTag("send_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Send,
                        contentDescription = "Send Command",
                        tint = if (inputText.isNotBlank()) accentColor else HologramTextDim,
                        modifier = Modifier.size(19.dp)
                    )
                }

                Spacer(modifier = Modifier.width(6.dp))

                // Voice Mic Button
                val isListening = voiceState == VoiceState.LISTENING
                Box(
                    modifier = Modifier
                        .size(46.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(if (isListening) AlertCrimson.copy(alpha = 0.3f) else ReactorCyanGlow.copy(alpha = 0.15f))
                        .border(1.2.dp, if (isListening) AlertCrimson else ReactorCyanGlow, RoundedCornerShape(6.dp))
                        .clickable { viewModel.toggleCoreMicLock() }
                        .testTag("mic_toggle_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.Stop else Icons.Default.Mic,
                        contentDescription = "Toggle Voice Receptor",
                        tint = if (isListening) AlertCrimson else ReactorCyanGlow,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun ConversationBubble(
    message: ConversationEntity,
    accentColor: Color,
    operatorName: String,
    imageModelName: String,
    onSpeak: () -> Unit
) {
    val isUser = message.sender == "USER"
    val timeStr = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date(message.timestamp))

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        // Sender header
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            Text(
                text = if (isUser) "OPERATOR // $operatorName" else "JARVIS // MARK-LIV",
                color = if (isUser) ReactorCyanGlow else accentColor,
                fontSize = 10.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = timeStr,
                color = HologramTextDim,
                fontSize = 9.sp,
                fontFamily = FontFamily.Monospace
            )
            if (!isUser) {
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Replay Vocalization",
                    tint = accentColor.copy(alpha = 0.7f),
                    modifier = Modifier
                        .size(14.dp)
                        .clickable { onSpeak() }
                )
            }
        }

        // Bubble Box
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(if (isUser) ReactorCyanGlow.copy(alpha = 0.12f) else HudCardSurface)
                .border(
                    width = 1.dp,
                    color = if (isUser) ReactorCyanGlow.copy(alpha = 0.35f) else accentColor.copy(alpha = 0.3f),
                    shape = RoundedCornerShape(6.dp)
                )
                .padding(10.dp)
        ) {
            Column {
                // If message has tool result attached
                if (message.toolName != null) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(4.dp))
                            .background(accentColor.copy(alpha = 0.15f))
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Icon(
                            imageVector = when (message.toolName) {
                                "IMAGE_GENERATOR" -> Icons.Default.Image
                                "GOOGLE_SEARCH" -> Icons.Default.Search
                                "GOOGLE_MAPS_ROUTE" -> Icons.Default.Directions
                                "GOOGLE_MAPS_PLACE" -> Icons.Default.Place
                                else -> Icons.Default.Build
                            },
                            contentDescription = "Tool Executed",
                            tint = accentColor,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = when (message.toolName) {
                                "IMAGE_GENERATOR" -> "NEURAL VISUAL MODEL // $imageModelName"
                                "GOOGLE_SEARCH" -> "LIVE GOOGLE SEARCH TELEMETRY"
                                "GOOGLE_MAPS_ROUTE" -> "REAL-TIME GOOGLE MAPS ROUTE TELEMETRY"
                                "GOOGLE_MAPS_PLACE" -> "REAL-TIME GOOGLE MAPS PLACE RADAR"
                                else -> "SUBSYSTEM TOOL: ${message.toolName.uppercase()}"
                            },
                            color = accentColor,
                            fontSize = 10.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                // Inline Generated or Attached Image Preview
                if (!message.imageUrl.isNullOrBlank() && message.imageUrl != "IMAGE_DATA") {
                    val file = File(message.imageUrl)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .border(1.dp, accentColor.copy(alpha = 0.4f), RoundedCornerShape(6.dp))
                            .background(Color.Black.copy(alpha = 0.5f))
                    ) {
                        AsyncImage(
                            model = file,
                            contentDescription = "Synthesized Neural Visual",
                            contentScale = ContentScale.Fit,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                }

                Text(
                    text = message.content,
                    color = HologramTextBright,
                    fontSize = 13.sp,
                    fontFamily = if (isUser) FontFamily.SansSerif else FontFamily.Monospace,
                    lineHeight = 18.sp
                )
            }
        }
    }
}
