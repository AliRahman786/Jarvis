package com.example.ai

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import kotlin.random.Random

class GeminiProvider : AiProvider {
    override val id: String = "GEMINI"
    override val displayName: String = "Google Gemini"
    override val supportedModels: List<String> = listOf(
        "gemini-2.0-flash",
        "gemini-2.0-flash-lite",
        "gemini-1.5-flash",
        "gemini-1.5-pro",
        "gemini-2.0-pro-exp-02-05"
    )
    override val defaultModel: String = "gemini-2.0-flash"

    private val httpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private fun normalizeModel(model: String): String {
        val trimmed = model.trim()
        if (trimmed.isBlank()) return defaultModel
        // Migrate legacy/invalid model names
        return when (trimmed.lowercase()) {
            "gemini-2.5-flash", "gemini-2.5-pro", "gemini-2.5-flash-lite", "gemini-3.1-flash-lite" -> "gemini-2.0-flash"
            else -> trimmed
        }
    }

    override suspend fun testConnection(apiKey: String, model: String): Result<String> = withContext(Dispatchers.IO) {
        val trimmedKey = apiKey.trim()
        if (trimmedKey.isBlank()) {
            return@withContext Result.failure(Exception("Gemini API key is required. Please configure your key in Settings."))
        }
        val cleanModel = normalizeModel(model)
        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$cleanModel:generateContent?key=$trimmedKey"
            val json = JSONObject().apply {
                put("contents", JSONArray().apply {
                    put(JSONObject().apply {
                        put("parts", JSONArray().apply {
                            put(JSONObject().apply { put("text", "JARVIS diagnostic ping. Respond: ONLINE.") })
                        })
                    })
                })
            }
            val request = Request.Builder()
                .url(url)
                .post(json.toString().toRequestBody("application/json".toMediaType()))
                .build()
            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: ""
            if (!response.isSuccessful) {
                val errorMsg = AiNetworkUtils.parseErrorMessage("Gemini", response.code, body)
                return@withContext Result.failure(Exception(errorMsg))
            }
            Result.success("Gemini ($cleanModel) verified successfully.")
        } catch (e: Exception) {
            Result.failure(Exception(AiNetworkUtils.parseException("Gemini", e)))
        }
    }

    override suspend fun generateResponse(
        apiKey: String,
        model: String,
        messages: List<ChatMessage>,
        systemInstruction: String,
        tools: List<ToolDefinition>
    ): Result<AiResponse> = withContext(Dispatchers.IO) {
        val trimmedKey = apiKey.trim()
        if (trimmedKey.isBlank()) {
            return@withContext Result.failure(Exception("API_KEY_MISSING: Gemini API key has not been configured."))
        }

        val activeModel = normalizeModel(model)

        // Bounded retries with exponential backoff and jitter for transient failures (429, 500, 502, 503, 504)
        var attempt = 0
        val maxAttempts = 3
        var lastException: Exception? = null

        while (attempt < maxAttempts) {
            attempt++
            val result = executeGenerateContent(
                apiKey = trimmedKey,
                model = activeModel,
                messages = messages,
                systemInstruction = systemInstruction,
                tools = tools
            )

            if (result.isSuccess) {
                return@withContext result
            }

            val exception = result.exceptionOrNull() as? Exception ?: Exception("Unknown error")
            lastException = exception
            val msg = exception.message ?: ""

            // Check if error is transient and retryable
            val isRateLimit = msg.contains("429") || msg.contains("Rate Limit", ignoreCase = true)
            val isServerOutage = msg.contains("500") || msg.contains("502") || msg.contains("503") || msg.contains("504")

            if ((isRateLimit || isServerOutage) && attempt < maxAttempts) {
                // Exponential backoff: attempt 1 -> ~1500ms + jitter, attempt 2 -> ~3000ms + jitter
                val baseDelay = (1500L * attempt)
                val jitter = Random.nextLong(200, 600)
                delay(baseDelay + jitter)
                continue
            } else {
                // Non-retryable error (e.g., 400, 401, 403, 404, 413) or exhausted retries
                return@withContext Result.failure(exception)
            }
        }

        Result.failure(lastException ?: Exception("Neural communication error after retries."))
    }

    private fun executeGenerateContent(
        apiKey: String,
        model: String,
        messages: List<ChatMessage>,
        systemInstruction: String,
        tools: List<ToolDefinition>
    ): Result<AiResponse> {
        try {
            val url = "https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent?key=$apiKey"
            val root = JSONObject()

            // System Instruction
            if (systemInstruction.isNotBlank()) {
                root.put("systemInstruction", JSONObject().apply {
                    put("parts", JSONArray().apply {
                        put(JSONObject().apply { put("text", systemInstruction) })
                    })
                })
            }

            // Register Subsystem Automation Tools
            if (tools.isNotEmpty()) {
                val functionDeclarations = JSONArray()
                for (tool in tools) {
                    val fnObj = JSONObject().apply {
                        put("name", tool.name)
                        put("description", tool.description)

                        val parametersObj = JSONObject().apply {
                            put("type", "OBJECT")
                            val propertiesObj = JSONObject()
                            val requiredArr = JSONArray()

                            for (param in tool.parameters) {
                                val paramProp = JSONObject().apply {
                                    put("type", param.type.uppercase())
                                    put("description", param.description)
                                }
                                propertiesObj.put(param.name, paramProp)
                                if (param.required) {
                                    requiredArr.put(param.name)
                                }
                            }

                            put("properties", propertiesObj)
                            if (requiredArr.length() > 0) {
                                put("required", requiredArr)
                            }
                        }
                        put("parameters", parametersObj)
                    }
                    functionDeclarations.put(fnObj)
                }

                root.put("tools", JSONArray().apply {
                    put(JSONObject().apply {
                        put("function_declarations", functionDeclarations)
                    })
                })
            }

            // Strict turn sequencing:
            // 1. Roles must be 'user' or 'model'
            // 2. Strict alternation: no two consecutive turns with the same role
            // 3. First turn MUST have role 'user'
            // 4. Last turn MUST have role 'user'
            val trimmedHistory = if (messages.size > 10) messages.takeLast(10) else messages
            val sanitizedTurns = mutableListOf<Pair<String, MutableList<JSONObject>>>()

            for (i in trimmedHistory.indices) {
                val msg = trimmedHistory[i]
                if (msg.content.isBlank() && msg.imageUrlBase64 == null) continue

                val role = if (msg.role == "assistant") "model" else "user"
                val partsList = mutableListOf<JSONObject>()

                // Only attach image to the very last message in the list if present
                if (i == trimmedHistory.lastIndex && msg.imageUrlBase64 != null) {
                    partsList.add(JSONObject().apply {
                        put("inline_data", JSONObject().apply {
                            put("mime_type", "image/jpeg")
                            put("data", msg.imageUrlBase64)
                        })
                    })
                }

                if (msg.content.isNotBlank()) {
                    partsList.add(JSONObject().apply {
                        put("text", msg.content)
                    })
                }

                if (partsList.isEmpty()) continue

                if (sanitizedTurns.isNotEmpty() && sanitizedTurns.last().first == role) {
                    // Merge consecutive parts into previous turn to guarantee strict alternation
                    sanitizedTurns.last().second.addAll(partsList)
                } else {
                    sanitizedTurns.add(Pair(role, partsList))
                }
            }

            // First turn MUST have role 'user'
            while (sanitizedTurns.isNotEmpty() && sanitizedTurns.first().first != "user") {
                sanitizedTurns.removeAt(0)
            }

            // If empty, supply a default user ping
            if (sanitizedTurns.isEmpty()) {
                val defaultParts = mutableListOf(JSONObject().apply { put("text", "JARVIS status report.") })
                sanitizedTurns.add(Pair("user", defaultParts))
            }

            // Last turn MUST have role 'user' for generateContent
            if (sanitizedTurns.isNotEmpty() && sanitizedTurns.last().first != "user") {
                // If the last message was from the model, append a user continuation
                val contParts = mutableListOf(JSONObject().apply { put("text", "Please proceed.") })
                sanitizedTurns.add(Pair("user", contParts))
            }

            val contentsArray = JSONArray()
            for (turn in sanitizedTurns) {
                val contentObj = JSONObject()
                contentObj.put("role", turn.first)
                val partsArr = JSONArray()
                for (p in turn.second) {
                    partsArr.put(p)
                }
                contentObj.put("parts", partsArr)
                contentsArray.put(contentObj)
            }
            root.put("contents", contentsArray)

            val request = Request.Builder()
                .url(url)
                .post(root.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = httpClient.newCall(request).execute()
            val body = response.body?.string() ?: ""

            if (!response.isSuccessful) {
                val errorMsg = AiNetworkUtils.parseErrorMessage("Gemini", response.code, body)
                return Result.failure(Exception(errorMsg))
            }

            val respJson = JSONObject(body)
            val candidates = respJson.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return Result.success(AiResponse("Systems active. Ready for next command."))
            }

            val firstCandidate = candidates.getJSONObject(0)
            val content = firstCandidate.optJSONObject("content")
            val parts = content?.optJSONArray("parts")

            var responseText = ""
            val toolCalls = mutableListOf<ToolCallRequest>()
            val groundingSources = mutableListOf<GroundingSource>()

            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val part = parts.getJSONObject(i)
                    if (part.has("text")) {
                        responseText += part.getString("text")
                    }
                    if (part.has("functionCall")) {
                        val fnCall = part.getJSONObject("functionCall")
                        val fnName = fnCall.optString("name", "")
                        val fnArgs = fnCall.optJSONObject("args")?.toString() ?: "{}"
                        toolCalls.add(
                            ToolCallRequest(
                                id = "call_${System.currentTimeMillis()}_$i",
                                name = fnName,
                                argumentsJson = fnArgs
                            )
                        )
                    }
                }
            }

            // Extract Grounding Metadata Citations
            val groundingMeta = firstCandidate.optJSONObject("groundingMetadata")
            if (groundingMeta != null) {
                val chunks = groundingMeta.optJSONArray("groundingChunks")
                if (chunks != null) {
                    for (c in 0 until chunks.length()) {
                        val chunkObj = chunks.getJSONObject(c)
                        val web = chunkObj.optJSONObject("web")
                        if (web != null) {
                            val title = web.optString("title", "Web Source")
                            val uri = web.optString("uri", "")
                            if (uri.isNotBlank()) {
                                groundingSources.add(GroundingSource(title, uri))
                            }
                        }
                    }
                }
            }

            return Result.success(
                AiResponse(
                    text = responseText.trim(),
                    toolCalls = toolCalls,
                    groundingSources = groundingSources
                )
            )
        } catch (e: Exception) {
            return Result.failure(Exception(AiNetworkUtils.parseException("Gemini", e)))
        }
    }

    suspend fun generateImage(
        apiKey: String,
        modelName: String,
        prompt: String,
        cacheDir: File
    ): Result<File> = withContext(Dispatchers.IO) {
        val cleanPrompt = prompt.trim()

        // Try direct Imagen / Gemini generation if API key present
        if (apiKey.isNotBlank()) {
            try {
                val targetModel = "imagen-3.0-generate-002"
                val url = "https://generativelanguage.googleapis.com/v1beta/models/$targetModel:predict?key=$apiKey"
                val bodyJson = JSONObject().apply {
                    put("instances", JSONArray().apply {
                        put(JSONObject().apply { put("prompt", cleanPrompt) })
                    })
                    put("parameters", JSONObject().apply {
                        put("sampleCount", 1)
                    })
                }

                val req = Request.Builder()
                    .url(url)
                    .post(bodyJson.toString().toRequestBody("application/json".toMediaType()))
                    .build()

                val resp = httpClient.newCall(req).execute()
                val respBody = resp.body?.string() ?: ""

                if (resp.isSuccessful && respBody.isNotBlank()) {
                    val j = JSONObject(respBody)
                    val predictions = j.optJSONArray("predictions")
                    if (predictions != null && predictions.length() > 0) {
                        val b64 = predictions.getJSONObject(0).optString("bytesBase64Encoded", "")
                        if (b64.isNotBlank()) {
                            val bytes = Base64.decode(b64, Base64.DEFAULT)
                            val outFile = File(cacheDir, "img_${System.currentTimeMillis()}.png")
                            FileOutputStream(outFile).use { it.write(bytes) }
                            return@withContext Result.success(outFile)
                        }
                    }
                }
            } catch (_: Exception) {}
        }

        // Guaranteed External Fallback: Fetch directly from Pollinations Flux API
        try {
            val encodedPrompt = URLEncoder.encode(cleanPrompt, "UTF-8")
            val fallbackUrl = "https://image.pollinations.ai/prompt/$encodedPrompt?width=1024&height=1024&nologo=true&model=flux"
            val fallbackReq = Request.Builder().url(fallbackUrl).build()
            val fallbackResp = httpClient.newCall(fallbackReq).execute()

            if (fallbackResp.isSuccessful) {
                val bytes = fallbackResp.body?.bytes()
                if (bytes != null && bytes.isNotEmpty()) {
                    val outFile = File(cacheDir, "img_${System.currentTimeMillis()}.jpg")
                    FileOutputStream(outFile).use { it.write(bytes) }
                    return@withContext Result.success(outFile)
                }
            }
        } catch (_: Exception) {}

        Result.failure(Exception("Image generation failed across neural matrix."))
    }

    override suspend fun generateStream(
        apiKey: String,
        model: String,
        messages: List<ChatMessage>,
        systemInstruction: String,
        tools: List<ToolDefinition>,
        onChunk: (String) -> Unit
    ): Result<AiResponse> {
        val res = generateResponse(apiKey, model, messages, systemInstruction, tools)
        if (res.isSuccess) {
            val text = res.getOrNull()?.text ?: ""
            onChunk(text)
        }
        return res
    }
}
