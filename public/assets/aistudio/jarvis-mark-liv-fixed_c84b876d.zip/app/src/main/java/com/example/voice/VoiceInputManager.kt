package com.example.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class VoiceInputManager(private val context: Context) {
    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _audioRmsDb = MutableStateFlow(0f)
    val audioRmsDb: StateFlow<Float> = _audioRmsDb.asStateFlow()

    private var onResultCallback: ((String) -> Unit)? = null
    private var onErrorCallback: ((String) -> Unit)? = null

    private var currentLanguageCode: String = "en-US"
    private var isPersistentMicLocked: Boolean = false

    // Guards to eliminate double pop sounds & echo
    var isComputing: Boolean = false
    var isJarvisSpeaking: Boolean = false
    var lastJarvisSpokenText: String = ""

    fun isAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun startListening(
        languageCode: String = "en-US",
        persistentLock: Boolean = false,
        onResult: (String) -> Unit,
        onError: (String) -> Unit
    ) {
        if (!isAvailable()) {
            onError("Speech recognition hardware or service unavailable on this device.")
            return
        }

        // STEP 2 Guard: Never start recognition while computing or while speaker is active
        if (_isListening.value || isComputing || isJarvisSpeaking) {
            return
        }

        currentLanguageCode = languageCode
        isPersistentMicLocked = persistentLock
        onResultCallback = onResult
        onErrorCallback = onError

        launchRecognizerInternal()
    }

    private fun launchRecognizerInternal() {
        if (isComputing || isJarvisSpeaking) {
            return
        }

        mainHandler.post {
            try {
                if (speechRecognizer == null) {
                    speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(object : RecognitionListener {
                        override fun onReadyForSpeech(params: Bundle?) {
                            _isListening.value = true
                        }

                        override fun onBeginningOfSpeech() {}

                        override fun onRmsChanged(rmsdB: Float) {
                            _audioRmsDb.value = (rmsdB.coerceIn(0f, 12f) / 12f)
                        }

                        override fun onBufferReceived(buffer: ByteArray?) {}

                        override fun onEndOfSpeech() {
                            _audioRmsDb.value = 0f
                            _isListening.value = false
                        }

                        override fun onError(error: Int) {
                            _audioRmsDb.value = 0f
                            _isListening.value = false

                            val isTransient = error == SpeechRecognizer.ERROR_NO_MATCH ||
                                    error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT ||
                                    error == SpeechRecognizer.ERROR_NETWORK_TIMEOUT ||
                                    error == SpeechRecognizer.ERROR_CLIENT

                            // Only auto-restart if NOT computing and NOT speaking
                            if (isPersistentMicLocked && !isComputing && !isJarvisSpeaking) {
                                mainHandler.postDelayed({
                                    if (isPersistentMicLocked && !isComputing && !isJarvisSpeaking) {
                                        launchRecognizerInternal()
                                    }
                                }, 350)
                            } else {
                                if (!isTransient) {
                                    val message = when (error) {
                                        SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                                        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission required"
                                        SpeechRecognizer.ERROR_NETWORK -> "Network error during speech recognition"
                                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Speech service is busy"
                                        SpeechRecognizer.ERROR_SERVER -> "Server error"
                                        else -> "Recognition error: code $error"
                                    }
                                    onErrorCallback?.invoke(message)
                                }
                            }
                        }

                        override fun onResults(results: Bundle?) {
                            _audioRmsDb.value = 0f
                            _isListening.value = false

                            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                            val rawText = matches?.firstOrNull()?.trim() ?: ""

                            if (rawText.isNotBlank()) {
                                // STEP 2: Anti-Echo Filter (discard transcript if > 40% match with what Jarvis just spoke)
                                val echoSimilarity = calculateSimilarity(rawText, lastJarvisSpokenText)
                                if (echoSimilarity < 0.40f) {
                                    onResultCallback?.invoke(rawText)
                                }
                            }

                            // Do NOT restart recognition if isComputing is true!
                            // Recognition will restart after computation and speaker output finish.
                            if (isPersistentMicLocked && !isComputing && !isJarvisSpeaking) {
                                mainHandler.postDelayed({
                                    if (isPersistentMicLocked && !isComputing && !isJarvisSpeaking) {
                                        launchRecognizerInternal()
                                    }
                                }, 400)
                            }
                        }

                        override fun onPartialResults(partialResults: Bundle?) {}

                        override fun onEvent(eventType: Int, params: Bundle?) {}
                    })
                }
            }

            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, currentLanguageCode)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, currentLanguageCode)
                    putExtra("android.speech.extra.EXTRA_ADDITIONAL_LANGUAGES", arrayOf(currentLanguageCode))
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                }
                speechRecognizer?.startListening(intent)
            } catch (e: Exception) {
                _isListening.value = false
                _audioRmsDb.value = 0f
                if (!isPersistentMicLocked) {
                    onErrorCallback?.invoke("Receptor initialization error: ${e.localizedMessage}")
                }
            }
        }
    }

    /**
     * Token overlap similarity to filter out Jarvis hearing its own speaker output
     */
    private fun calculateSimilarity(input: String, reference: String): Float {
        if (input.isBlank() || reference.isBlank()) return 0f
        val inputTokens = input.lowercase(Locale.ROOT).split(Regex("\\s+")).filter { it.length > 2 }.toSet()
        val refTokens = reference.lowercase(Locale.ROOT).split(Regex("\\s+")).filter { it.length > 2 }.toSet()
        if (inputTokens.isEmpty() || refTokens.isEmpty()) return 0f
        val intersection = inputTokens.intersect(refTokens).size
        return intersection.toFloat() / maxOf(inputTokens.size, 1)
    }

    fun setPersistentMicLock(locked: Boolean) {
        isPersistentMicLocked = locked
        if (!locked) {
            stopListening()
        }
    }

    fun isPersistentLock(): Boolean = isPersistentMicLocked

    fun restartIfLocked() {
        if (isPersistentMicLocked && !isComputing && !isJarvisSpeaking && !_isListening.value) {
            launchRecognizerInternal()
        }
    }

    fun stopListening() {
        mainHandler.removeCallbacksAndMessages(null)
        try {
            speechRecognizer?.stopListening()
            speechRecognizer?.destroy()
        } catch (_: Exception) {}
        speechRecognizer = null
        _isListening.value = false
        _audioRmsDb.value = 0f
    }
}
