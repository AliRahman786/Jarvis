package com.example.viewmodel

import android.annotation.SuppressLint
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.location.Location
import android.location.LocationManager
import android.util.Base64
import androidx.compose.ui.graphics.Color
import androidx.core.content.ContextCompat
import java.util.Locale
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.ai.AiProvider
import com.example.ai.ChatMessage
import com.example.ai.GeminiProvider
import com.example.ai.GroqProvider
import com.example.ai.OpenAiProvider
import com.example.ai.ToolCallRequest
import com.example.ai.ToolDefinition
import com.example.ai.ToolParameter
import com.example.data.location.DeviceLocationManager
import com.example.data.location.LocationStatus
import com.example.automation.DeviceActionController
import com.example.automation.JarvisAccessibilityService
import com.example.data.battery.BatteryPowerState
import com.example.data.battery.SystemBatteryObserver
import com.example.data.db.AppDatabase
import com.example.data.memory.MemoryManager
import com.example.data.model.ConversationEntity
import com.example.data.prefs.JarvisPersona
import com.example.data.prefs.PreferencesManager
import com.example.data.repository.ConversationRepository
import com.example.data.weather.LiveWeatherData
import com.example.data.weather.WeatherManager
import com.example.maps.GoogleMapsAgentEngine
import com.example.maps.PlaceLocation
import com.example.maps.RouteCalculation
import com.example.search.GoogleSearchEngine
import com.example.service.JarvisBackgroundService
import com.example.sound.SciFiSoundManager
import com.example.ui.theme.ThemeCyberYellow
import com.example.ui.theme.ThemeElectricBlue
import com.example.ui.theme.ThemeNeonGreen
import com.example.ui.theme.ThemeQuantumPurple
import com.example.ui.theme.ThemeReactorRed
import com.example.ui.theme.ThemeSolarOrange
import com.example.voice.VoiceInputManager
import com.example.voice.VoiceOutputManager
import com.example.voice.VoiceState
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

sealed class ApiValidationState {
    object Idle : ApiValidationState()
    object Validating : ApiValidationState()
    data class Success(val message: String) : ApiValidationState()
    data class Error(val message: String) : ApiValidationState()
}

class JarvisViewModel(application: Application) : AndroidViewModel(application) {
    val prefs = PreferencesManager(application)
    val memoryManager = MemoryManager(application)
    private val db = AppDatabase.getInstance(application)
    val conversationRepo = ConversationRepository(db.conversationDao())
    val batteryObserver = SystemBatteryObserver(application, prefs)
    val batteryPowerState: StateFlow<BatteryPowerState> = batteryObserver.powerStateFlow

    val voiceInputManager = VoiceInputManager(application)
    val voiceOutputManager = VoiceOutputManager(application)
    val weatherManager = WeatherManager()
    val weatherData: StateFlow<LiveWeatherData> = weatherManager.weatherState

    // Direct Gemini Provider instance
    val geminiProvider = GeminiProvider()

    // Navigation and UI state
    private val _activePanel = MutableStateFlow("HOME")
    val activePanel: StateFlow<String> = _activePanel.asStateFlow()

    private val _voiceState = MutableStateFlow(VoiceState.IDLE)
    val voiceState: StateFlow<VoiceState> = _voiceState.asStateFlow()

    // PART 1: Persistent Core Mic Lock State (Manual On/Off Only)
    private val _isCoreMicLockedOn = MutableStateFlow(false)
    val isCoreMicLockedOn: StateFlow<Boolean> = _isCoreMicLockedOn.asStateFlow()

    private val _statusText = MutableStateFlow("JARVIS MARK-LIV ONLINE // AWAITING COMMAND")
    val statusText: StateFlow<String> = _statusText.asStateFlow()

    private val _inputText = MutableStateFlow("")
    val inputText: StateFlow<String> = _inputText.asStateFlow()

    private val _apiValidationState = MutableStateFlow<ApiValidationState>(ApiValidationState.Idle)
    val apiValidationState: StateFlow<ApiValidationState> = _apiValidationState.asStateFlow()

    // Camera Vision & Screen Vision States
    private val _isCameraVisionActive = MutableStateFlow(false)
    val isCameraVisionActive: StateFlow<Boolean> = _isCameraVisionActive.asStateFlow()

    private val _isScreenVisionActive = MutableStateFlow(false)
    val isScreenVisionActive: StateFlow<Boolean> = _isScreenVisionActive.asStateFlow()

    private val _triggerCameraCapture = MutableStateFlow(false)
    val triggerCameraCapture: StateFlow<Boolean> = _triggerCameraCapture.asStateFlow()

    // Tactical Sci-Fi Google Map States
    private val _isTacticalMapActive = MutableStateFlow(false)
    val isTacticalMapActive: StateFlow<Boolean> = _isTacticalMapActive.asStateFlow()

    private val _mapCity = MutableStateFlow(prefs.getUserLocationCity())
    val mapCity: StateFlow<String> = _mapCity.asStateFlow()

    private val _mapLatitude = MutableStateFlow(prefs.getUserLocationLat())
    val mapLatitude: StateFlow<Double> = _mapLatitude.asStateFlow()

    private val _mapLongitude = MutableStateFlow(prefs.getUserLocationLon())
    val mapLongitude: StateFlow<Double> = _mapLongitude.asStateFlow()

    private val _showLocationModal = MutableStateFlow(false)
    val showLocationModal: StateFlow<Boolean> = _showLocationModal.asStateFlow()

    fun openLocationModal() { _showLocationModal.value = true }
    fun closeLocationModal() { _showLocationModal.value = false }

    private val _activeRoute = MutableStateFlow<RouteCalculation?>(null)
    val activeRoute: StateFlow<RouteCalculation?> = _activeRoute.asStateFlow()

    private val _activePlace = MutableStateFlow<PlaceLocation?>(null)
    val activePlace: StateFlow<PlaceLocation?> = _activePlace.asStateFlow()

    private var pendingVoiceQueryAfterCapture: String? = null

    // Combined amplitude for holographic waveform visualizer
    val combinedAudioAmplitude: StateFlow<Float> = combine(
        voiceInputManager.audioRmsDb,
        voiceOutputManager.speechAmplitude
    ) { inAmp, outAmp ->
        maxOf(inAmp, outAmp)
    }.stateIn(viewModelScope, SharingStarted.Eagerly, 0f)

    // Conversation message history stream for Terminal panel
    val conversationMessages: StateFlow<List<ConversationEntity>> = conversationRepo
        .currentMessages
        .stateIn(viewModelScope, SharingStarted.Lazily, emptyList<ConversationEntity>())

    // Defined Gemini Function Calling Tools
    val automationTools = listOf(
        ToolDefinition(
            name = "searchGoogle",
            description = "Search Google and knowledge bases silently in the background for real-time facts, answers to questions, news, or definitions without opening an external browser.",
            parameters = listOf(
                ToolParameter("query", "STRING", "The search query or question to look up", required = true)
            )
        ),
        ToolDefinition(
            name = "showTacticalMap",
            description = "Display and focus the live Google Map on the HUD for a specific city, country, or location.",
            parameters = listOf(
                ToolParameter("locationName", "STRING", "The city or location name to show on the map", required = true),
                ToolParameter("latitude", "NUMBER", "Optional latitude", required = false),
                ToolParameter("longitude", "NUMBER", "Optional longitude", required = false)
            )
        ),
        ToolDefinition(
            name = "getRouteDirections",
            description = "Calculate real-time route, distance, travel duration, and turn-by-turn directions between an origin and destination on Google Maps.",
            parameters = listOf(
                ToolParameter("origin", "STRING", "Starting location or address (e.g. New York, Current Location)", required = true),
                ToolParameter("destination", "STRING", "Ending destination or address (e.g. Boston)", required = true),
                ToolParameter("travelMode", "STRING", "Travel mode: driving, walking, or transit", required = false)
            )
        ),
        ToolDefinition(
            name = "getPlaceInfo",
            description = "Pull real-time information, coordinates, address, and summary about a place, landmark, city, or address.",
            parameters = listOf(
                ToolParameter("placeName", "STRING", "The name of the place, landmark, or address to look up", required = true),
                ToolParameter("category", "STRING", "Optional category or place type", required = false)
            )
        ),
        ToolDefinition(
            name = "searchNearbyPlaces",
            description = "Search for nearby places of interest (e.g. restaurants, coffee shops, hotels, hospitals, gas stations) around a location.",
            parameters = listOf(
                ToolParameter("location", "STRING", "The center location or landmark (e.g. Central Park, Tokyo)", required = true),
                ToolParameter("placeType", "STRING", "The type of amenity to search for (e.g. restaurant, coffee, hospital)", required = true)
            )
        ),
        ToolDefinition(
            name = "playOnYouTube",
            description = "Search and immediately play a video or music query on YouTube.",
            parameters = listOf(
                ToolParameter("query", "STRING", "The video title, artist, or song to play", required = true)
            )
        ),
        ToolDefinition(
            name = "sendWhatsAppMessage",
            description = "Send a WhatsApp message to a named contact or phone number.",
            parameters = listOf(
                ToolParameter("recipient", "STRING", "The name of the contact or relationship (e.g. father, mom, John)", required = true),
                ToolParameter("message", "STRING", "The text message content to send", required = true)
            )
        ),
        ToolDefinition(
            name = "callContact",
            description = "Place a direct phone call to a named contact or phone number.",
            parameters = listOf(
                ToolParameter("nameOrNumber", "STRING", "The contact name or telephone number to dial", required = true)
            )
        ),
        ToolDefinition(
            name = "openApp",
            description = "Launch an installed Android application by name (e.g. YouTube, Chrome, Settings, Camera, Spotify, Maps).",
            parameters = listOf(
                ToolParameter("appName", "STRING", "The common name of the application to open", required = true)
            )
        ),
        ToolDefinition(
            name = "generateImage",
            description = "Generate a custom high-resolution image using the configured image model (e.g., Nano Banana 2).",
            parameters = listOf(
                ToolParameter("prompt", "STRING", "The detailed visual prompt describing the scene, object, or art to generate", required = true)
            )
        ),
        ToolDefinition(
            name = "saveMemory",
            description = "Store a critical user detail, personal preference, or relationship into persistent Memory Core.",
            parameters = listOf(
                ToolParameter("key", "STRING", "The memory key (e.g. favorite_color, brother_name, project)", required = true),
                ToolParameter("value", "STRING", "The memory content or fact", required = true)
            )
        ),
        ToolDefinition(
            name = "deleteMemory",
            description = "Purge a specified memory from long-term neural recall.",
            parameters = listOf(
                ToolParameter("key", "STRING", "The exact memory key to remove", required = true)
            )
        ),
        ToolDefinition(
            name = "setThemeColor",
            description = "Change the holographic UI accent color (BLUE, YELLOW, RED, GREEN, PURPLE, ORANGE).",
            parameters = listOf(
                ToolParameter("color", "STRING", "The color theme name", required = true)
            )
        ),
        ToolDefinition(
            name = "clickOnScreen",
            description = "Simulate a tap on a specific button, link, or text visible on screen via accessibility.",
            parameters = listOf(
                ToolParameter("targetText", "STRING", "The text or label of the UI element to tap", required = true)
            )
        ),
        ToolDefinition(
            name = "scrollScreen",
            description = "Scroll the current active screen up or down.",
            parameters = listOf(
                ToolParameter("direction", "STRING", "forward (down) or backward (up)", required = true)
            )
        )
    )

    init {
        batteryObserver.start()

        // Synchronize accurate user location and live weather on startup
        viewModelScope.launch {
            val userCity = prefs.getUserLocationCity()
            val userLat = prefs.getUserLocationLat()
            val userLon = prefs.getUserLocationLon()
            _mapCity.value = userCity
            _mapLatitude.value = userLat
            _mapLongitude.value = userLon
            weatherManager.refreshWeather(lat = userLat, lon = userLon, cityName = userCity)

            if (!prefs.isLocationConfigured()) {
                _showLocationModal.value = true
                speakVoice("Ali Rahman, please confirm your current location so I can calibrate your in-built tactical Google map and live weather forecast.")
            }
        }

        // Auto-start persistent background service if enabled and mic permission is already granted
        val hasMicPermission = ContextCompat.checkSelfPermission(
            application,
            android.Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED
        if (prefs.isBackgroundServiceEnabled() && hasMicPermission) {
            JarvisBackgroundService.start(application)
        }

        // Initialize voice output engine with active persona, language, and neural voice
        voiceOutputManager.applyPersona(
            persona = prefs.getActivePersona(),
            languageCode = prefs.getVoiceLanguage(),
            customPitch = prefs.getSpeechPitch(),
            customRate = prefs.getSpeechRate(),
            neuralVoice = prefs.getNeuralVoiceName()
        )

        // Wire voice output state changes - NEVER mute mic if isCoreMicLockedOn is true!
        viewModelScope.launch {
            voiceOutputManager.isSpeaking.collect { isSpeaking ->
                if (isSpeaking) {
                    _voiceState.value = VoiceState.SPEAKING
                } else {
                    if (_isCoreMicLockedOn.value) {
                        _voiceState.value = VoiceState.LISTENING
                        _statusText.value = "MIC ON • READY"
                    } else if (_voiceState.value == VoiceState.SPEAKING) {
                        _voiceState.value = VoiceState.IDLE
                    }
                }
            }
        }
    }

    fun setActivePanel(panel: String) {
        _activePanel.value = panel
    }

    // PART 1: CORE ORB MANUAL TOGGLE SWITCH
    fun toggleCoreMicLock() {
        if (_isCoreMicLockedOn.value) {
            // 2nd Tap / Click: Manually turns mic OFF
            _isCoreMicLockedOn.value = false
            voiceInputManager.setPersistentMicLock(false)
            voiceInputManager.stopListening()
            _voiceState.value = VoiceState.IDLE
            _statusText.value = "JARVIS OFF • TAP TO START"
            SciFiSoundManager.playMicCloseSound()
        } else {
            // 1st Tap / Click: Turns mic ON and locks continuously
            _isCoreMicLockedOn.value = true
            voiceInputManager.setPersistentMicLock(true)
            startVoiceInput()
            SciFiSoundManager.playMicOpenSound()
        }
    }

    // TACTICAL MAP CONTROLS
    fun toggleTacticalMap() {
        _isTacticalMapActive.value = !_isTacticalMapActive.value
        _statusText.value = if (_isTacticalMapActive.value) "TACTICAL GOOGLE MAP ENGAGED" else "TACTICAL MAP STANDBY"
        if (_isTacticalMapActive.value) {
            speakVoice("Tactical Google Map feed engaged.")
        }
    }

    fun setTacticalMapActive(active: Boolean) {
        _isTacticalMapActive.value = active
    }

    fun setMapLocation(city: String, lat: Double, lon: Double) {
        _mapCity.value = city
        _mapLatitude.value = lat
        _mapLongitude.value = lon
        _isTacticalMapActive.value = true
        _statusText.value = "SAT-NAV LOCK // $city ($lat, $lon)"
    }

    fun updateUserLocation(cityName: String, lat: Double? = null, lon: Double? = null) {
        viewModelScope.launch {
            _statusText.value = "LOCKING TACTICAL COORDINATES..."
            _voiceState.value = VoiceState.THINKING

            var resolvedLat = lat
            var resolvedLon = lon
            var resolvedName = cityName.trim()

            if (resolvedLat == null || resolvedLon == null) {
                val place = GoogleMapsAgentEngine.geocode(resolvedName)
                resolvedLat = place.latitude
                resolvedLon = place.longitude
                resolvedName = place.name
            }

            prefs.setUserLocation(resolvedName, resolvedLat, resolvedLon)
            _mapCity.value = resolvedName
            _mapLatitude.value = resolvedLat
            _mapLongitude.value = resolvedLon
            _isTacticalMapActive.value = true

            val weatherData = weatherManager.refreshWeather(resolvedLat, resolvedLon, resolvedName)

            val successMsg = "🛰️ TACTICAL LOCATION SYNCHRONIZED // $resolvedName\n" +
                    "• Coordinates: ${String.format(Locale.ROOT, "%.4f", resolvedLat)}°N, ${String.format(Locale.ROOT, "%.4f", resolvedLon)}°E\n" +
                    "• Live Forecast: ${weatherData.temperature}°C, ${weatherData.condition} (High ${weatherData.high}°C / Low ${weatherData.low}°C, ${weatherData.humidity}% humidity)\n" +
                    "• In-built tactical map and real-time routing origin calibrated."

            conversationRepo.addMessage(
                sender = "JARVIS",
                content = successMsg,
                toolName = "LOCATION_SYNC"
            )

            _statusText.value = if (_isCoreMicLockedOn.value) "MIC ON • READY" else "POSITION LOCKED // $resolvedName"
            _voiceState.value = if (_isCoreMicLockedOn.value) VoiceState.LISTENING else VoiceState.IDLE

            speakVoice("Tactical location confirmed for Ali Rahman. Position locked on $resolvedName. In-built Google map centered and live weather forecast synchronized: ${weatherData.temperature} degrees Celsius, ${weatherData.condition}.")
        }
    }

    fun detectDeviceGpsLocation(context: Context, onComplete: ((String) -> Unit)? = null) {
        viewModelScope.launch {
            val locManager = DeviceLocationManager(context)
            if (!locManager.hasLocationPermission()) {
                _statusText.value = "LOCATION PERMISSION REQUIRED"
                speakVoice("Location access required. Please grant location access or pick your city from the list.")
                return@launch
            }

            _statusText.value = "ACQUIRING FRESH DEVICE LOCATION FIX..."
            _voiceState.value = VoiceState.THINKING

            when (val status = locManager.getCurrentLocation()) {
                is LocationStatus.Success -> {
                    val loc = status.result
                    val lat = loc.latitude
                    val lon = loc.longitude
                    val place = GoogleMapsAgentEngine.reverseGeocode(lat, lon)
                    val precisionLabel = if (loc.isPrecise) "PRECISE GPS LOCK" else "APPROXIMATE POSITION"
                    _statusText.value = "$precisionLabel // ${place.name}"
                    updateUserLocation(place.name, lat, lon)
                    onComplete?.invoke(place.name)
                }
                is LocationStatus.LocationServicesDisabled -> {
                    _statusText.value = "LOCATION SERVICES DISABLED"
                    speakVoice("Device location is turned off. Please turn on Location in Android settings.")
                }
                is LocationStatus.PermissionDenied -> {
                    _statusText.value = "LOCATION PERMISSION DENIED"
                    speakVoice("Location permission was not granted. You can select your city manually.")
                }
                is LocationStatus.Error -> {
                    _statusText.value = "LOCATION TIMED OUT // MANUAL CITY ACTIVE"
                    val currentCity = prefs.getUserLocationCity()
                    updateUserLocation(currentCity)
                    onComplete?.invoke(currentCity)
                    speakVoice("Could not acquire a fresh satellite fix. Keeping manual city: $currentCity.")
                }
            }
        }
    }

    fun clearTacticalRoute() {
        _activeRoute.value = null
        _activePlace.value = null
        _statusText.value = "TACTICAL VECTOR CLEARED"
    }

    fun findRouteAndDirections(origin: String, destination: String, mode: String = "driving") {
        val cleanOrig = origin.trim()
        val cleanDest = destination.trim()
        if (cleanDest.isBlank()) return

        viewModelScope.launch {
            _statusText.value = "CALCULATING REAL-TIME ROUTE TELEMETRY..."
            _voiceState.value = VoiceState.THINKING
            val userDefaultCity = prefs.getUserLocationCity()
            val orig = if (cleanOrig.isBlank() || cleanOrig.equals("current location", ignoreCase = true) ||
                cleanOrig.equals("my location", ignoreCase = true) || cleanOrig.equals("here", ignoreCase = true)) {
                userDefaultCity
            } else {
                cleanOrig
            }
            conversationRepo.addMessage(sender = "USER", content = "Directions from $orig to $cleanDest")

            val route = GoogleMapsAgentEngine.calculateRoute(orig, cleanDest, mode)
            _activeRoute.value = route
            _activePlace.value = null
            _mapCity.value = "${route.originName} ➔ ${route.destName}"
            _mapLatitude.value = route.startLat
            _mapLongitude.value = route.startLon
            _isTacticalMapActive.value = true

            val stepsText = if (route.steps.isNotEmpty()) {
                "\nTurn Guidance:\n" + route.steps.take(4).mapIndexed { i, s -> "${i + 1}. ${s.instruction} (${s.distanceText})" }.joinToString("\n")
            } else ""

            val report = "📍 NAVIGATION VECTOR: ${route.originName} ➔ ${route.destName}\n" +
                    "• Distance: ${route.distanceText}\n" +
                    "• Duration: ${route.durationText} (${route.mode})\n" +
                    "• Corridor: ${route.primaryRoad}$stepsText"

            conversationRepo.addMessage(
                sender = "JARVIS",
                content = report,
                toolName = "GOOGLE_MAPS_ROUTE"
            )

            _statusText.value = if (_isCoreMicLockedOn.value) "MIC ON • READY" else "VECTOR LOCKED // ${route.distanceText}"
            if (_isCoreMicLockedOn.value) {
                _voiceState.value = VoiceState.LISTENING
            } else {
                _voiceState.value = VoiceState.IDLE
            }

            speakVoice(route.telemetrySummary)
        }
    }

    fun findPlaceInformation(query: String, category: String = "") {
        val cleanQuery = query.trim()
        if (cleanQuery.isBlank()) return

        viewModelScope.launch {
            _statusText.value = "GEO-LOCATING REAL-TIME PLACE TELEMETRY..."
            _voiceState.value = VoiceState.THINKING
            conversationRepo.addMessage(sender = "USER", content = "Tell me about $cleanQuery")

            val place = GoogleMapsAgentEngine.geocode(cleanQuery)
            _activePlace.value = place
            _activeRoute.value = null
            _mapCity.value = place.name
            _mapLatitude.value = place.latitude
            _mapLongitude.value = place.longitude
            _isTacticalMapActive.value = true

            val report = "🛰️ REAL-TIME PLACE TELEMETRY: ${place.name}\n" +
                    "• Coordinates: ${String.format("%.4f", place.latitude)}°N, ${String.format("%.4f", place.longitude)}°E\n" +
                    "• Category: ${place.category}\n" +
                    "• Address: ${place.address}\n" +
                    "• Rating: ${place.rating} / 5.0"

            conversationRepo.addMessage(
                sender = "JARVIS",
                content = report,
                toolName = "GOOGLE_MAPS_PLACE"
            )

            _statusText.value = if (_isCoreMicLockedOn.value) "MIC ON • READY" else "POSITION LOCKED // ${place.name}"
            if (_isCoreMicLockedOn.value) {
                _voiceState.value = VoiceState.LISTENING
            } else {
                _voiceState.value = VoiceState.IDLE
            }

            speakVoice(place.summary)
        }
    }

    fun searchNearbyPlaces(location: String, placeType: String) {
        val userCity = prefs.getUserLocationCity()
        val cleanLoc = location.trim().let {
            if (it.isBlank() || it.equals("near me", ignoreCase = true) || it.equals("here", ignoreCase = true) || it.equals("current location", ignoreCase = true)) {
                userCity
            } else it
        }
        val cleanType = placeType.trim()

        viewModelScope.launch {
            _statusText.value = "SCANNING SATELLITE RADAR FOR $cleanType..."
            _voiceState.value = VoiceState.THINKING
            conversationRepo.addMessage(sender = "USER", content = "Find $cleanType near $cleanLoc")

            val places = GoogleMapsAgentEngine.searchPlaces(cleanType, cleanLoc)
            if (places.isNotEmpty()) {
                val first = places.first()
                _activePlace.value = first
                _activeRoute.value = null
                _mapCity.value = first.name
                _mapLatitude.value = first.latitude
                _mapLongitude.value = first.longitude
                _isTacticalMapActive.value = true

                val listFormatted = places.take(4).mapIndexed { i, p ->
                    "${i + 1}. ${p.name} • ${p.category} (${p.rating}★)\n   ${p.address}"
                }.joinToString("\n")

                val report = "🔍 REAL-TIME PLACES RADAR (${cleanType.uppercase()} NEAR $cleanLoc):\n$listFormatted"

                conversationRepo.addMessage(
                    sender = "JARVIS",
                    content = report,
                    toolName = "GOOGLE_MAPS_PLACE"
                )

                val spokenSummary = "Found ${places.size} locations for $cleanType near $cleanLoc. Top target is ${first.name}."
                speakVoice(spokenSummary)
            } else {
                val err = "No real-time telemetry detected for $cleanType near $cleanLoc."
                conversationRepo.addMessage(sender = "JARVIS", content = err, toolName = "GOOGLE_MAPS_PLACE")
                speakVoice(err)
            }

            _statusText.value = if (_isCoreMicLockedOn.value) "MIC ON • READY" else "RADAR SCAN COMPLETE"
            if (_isCoreMicLockedOn.value) {
                _voiceState.value = VoiceState.LISTENING
            } else {
                _voiceState.value = VoiceState.IDLE
            }
        }
    }

    fun refreshWeather() {
        viewModelScope.launch {
            _statusText.value = "UPDATING METEOROLOGICAL TELEMETRY..."
            weatherManager.refreshWeather()
            _statusText.value = "TELEMETRY SYNCHRONIZED"
        }
    }

    fun setActivePersona(persona: JarvisPersona) {
        prefs.setActivePersona(persona)
        voiceOutputManager.applyPersona(
            persona = persona,
            languageCode = prefs.getVoiceLanguage(),
            customPitch = prefs.getSpeechPitch(),
            customRate = prefs.getSpeechRate(),
            neuralVoice = prefs.getNeuralVoiceName()
        )
        _statusText.value = "NEURAL PROFILE ENGAGED // ${persona.displayName}"
    }

    fun setVoiceLanguage(languageCode: String) {
        prefs.setVoiceLanguage(languageCode)
        voiceOutputManager.applyPersona(
            persona = prefs.getActivePersona(),
            languageCode = languageCode,
            customPitch = prefs.getSpeechPitch(),
            customRate = prefs.getSpeechRate(),
            neuralVoice = prefs.getNeuralVoiceName()
        )
        _statusText.value = "VOICE MATRIX ALIGNED // $languageCode"
    }

    fun setNeuralVoice(voiceName: String) {
        prefs.setNeuralVoiceName(voiceName)
        voiceOutputManager.applyPersona(
            persona = prefs.getActivePersona(),
            languageCode = prefs.getVoiceLanguage(),
            customPitch = prefs.getSpeechPitch(),
            customRate = prefs.getSpeechRate(),
            neuralVoice = voiceName
        )
        _statusText.value = "NEURAL VOICE PIPELINE // $voiceName"
    }

    fun setImageGenModel(modelName: String) {
        prefs.setImageGenModel(modelName)
        _statusText.value = "IMAGE MODEL ROUTED // $modelName"
    }

    fun previewPersonaVoice(persona: JarvisPersona) {
        voiceOutputManager.previewVoice(
            voiceName = persona.defaultVoiceName,
            sampleText = persona.sampleGreeting
        )
    }

    fun previewSelectedVoice(voiceName: String) {
        voiceOutputManager.previewVoice(
            voiceName = voiceName,
            sampleText = "Voice profile verified. Operating at optimal parameters."
        )
    }

    fun previewNeuralVoice(voiceName: String) {
        previewSelectedVoice(voiceName)
    }

    fun setSpeechPitch(pitch: Float) {
        prefs.setSpeechPitch(pitch)
        voiceOutputManager.applyPersona(
            persona = prefs.getActivePersona(),
            languageCode = prefs.getVoiceLanguage(),
            customPitch = pitch,
            customRate = prefs.getSpeechRate(),
            neuralVoice = prefs.getNeuralVoiceName()
        )
    }

    fun setSpeechRate(rate: Float) {
        prefs.setSpeechRate(rate)
        voiceOutputManager.applyPersona(
            persona = prefs.getActivePersona(),
            languageCode = prefs.getVoiceLanguage(),
            customPitch = prefs.getSpeechPitch(),
            customRate = rate,
            neuralVoice = prefs.getNeuralVoiceName()
        )
    }

    fun setInputText(text: String) {
        _inputText.value = text
    }

    fun getAccentColor(): Color {
        return when (prefs.getAccentColor()) {
            "YELLOW" -> ThemeCyberYellow
            "RED" -> ThemeReactorRed
            "GREEN" -> ThemeNeonGreen
            "PURPLE" -> ThemeQuantumPurple
            "ORANGE" -> ThemeSolarOrange
            else -> ThemeElectricBlue
        }
    }

    fun setAccentColorTheme(themeName: String) {
        prefs.setAccentColor(themeName)
        _statusText.value = "THEME SHIFTED // ${themeName.uppercase()}"
    }

    fun setGeminiModel(model: String) {
        prefs.setGeminiModel(model)
        _statusText.value = "AI CORE MODEL SHIFTED // $model"
    }

    fun testActiveApiKey(providerId: String = prefs.getActiveAiProvider(), key: String, model: String) {
        viewModelScope.launch {
            _apiValidationState.value = ApiValidationState.Validating
            val provider: AiProvider = when (providerId.uppercase().trim()) {
                "OPENAI" -> openAiProvider
                "GROQ" -> groqProvider
                else -> geminiProvider
            }
            val result = provider.testConnection(key, model)
            if (result.isSuccess) {
                _apiValidationState.value = ApiValidationState.Success(result.getOrNull() ?: "Connection verified.")
            } else {
                _apiValidationState.value = ApiValidationState.Error(result.exceptionOrNull()?.message ?: "Validation failed.")
            }
        }
    }


    fun completeOnboarding() {
        prefs.setOnboardingCompleted(true)
        val name = prefs.getUserName().uppercase()
        _statusText.value = "MARK-LIV INITIALIZATION COMPLETE // WELCOME $name"
        speakVoice("Systems initialized. Good to see you, ${prefs.getUserName()}. JARVIS Mark-LIV is online and listening.")
    }

    fun saveMemory(key: String, value: String) {
        memoryManager.saveMemory(key, value)
        _statusText.value = "MEMORY RECORDED // ${key.uppercase()}"
    }

    fun deleteMemory(key: String) {
        memoryManager.deleteMemory(key)
        _statusText.value = "MEMORY PURGED // ${key.uppercase()}"
    }

    fun toggleCameraVision() {
        _isCameraVisionActive.value = !_isCameraVisionActive.value
        _statusText.value = if (_isCameraVisionActive.value) "LIVE CAMERA VISION ENGAGED" else "CAMERA VISION STANDBY"
        if (_isCameraVisionActive.value) {
            speakVoice("Camera vision online. Point at an object and ask what you see.")
        }
    }

    fun setCameraVisionActive(active: Boolean) {
        _isCameraVisionActive.value = active
    }

    fun toggleScreenVision() {
        _isScreenVisionActive.value = !_isScreenVisionActive.value
        _statusText.value = if (_isScreenVisionActive.value) "BACKGROUND SCREEN VISION ENGAGED" else "SCREEN VISION STANDBY"
        if (_isScreenVisionActive.value) {
            speakVoice("Screen vision active. I am monitoring your display in the background.")
        }
    }

    fun onCameraFrameCaptured(bitmap: Bitmap?) {
        _triggerCameraCapture.value = false
        val query = pendingVoiceQueryAfterCapture ?: "Identify and describe this object in detail."
        pendingVoiceQueryAfterCapture = null
        sendUserMessage(query, bitmap)
    }

    fun captureAndAnalyzeScreen(userQuery: String) {
        val accessibility = JarvisAccessibilityService.instance
        if (accessibility == null) {
            val alert = "Accessibility service is required for screen capture. Please enable it in Settings."
            speakVoice(alert)
            _statusText.value = "ACCESSIBILITY SERVICE REQUIRED"
            return
        }

        _statusText.value = "CAPTURING BACKGROUND SCREEN MATRIX..."
        accessibility.captureScreen { bitmap ->
            if (bitmap != null) {
                sendUserMessage(userQuery, bitmap)
            } else {
                _statusText.value = "SCREEN CAPTURE INACCESSIBLE"
                sendUserMessage(userQuery, null)
            }
        }
    }

    fun toggleVoiceInput() {
        toggleCoreMicLock()
    }

    fun startVoiceInput() {
        _voiceState.value = VoiceState.LISTENING
        _statusText.value = if (_isCoreMicLockedOn.value) "MIC ON • READY" else "LISTENING // SPEAK COMMAND"
        val lang = prefs.getVoiceLanguage()
        voiceInputManager.startListening(
            languageCode = lang,
            persistentLock = _isCoreMicLockedOn.value,
            onResult = { recognizedText ->
                if (!_isCoreMicLockedOn.value) {
                    _voiceState.value = VoiceState.IDLE
                }
                handleRecognizedSpeech(recognizedText)
            },
            onError = { error ->
                if (!_isCoreMicLockedOn.value) {
                    _voiceState.value = VoiceState.ERROR
                    _statusText.value = "VOICE ERROR: $error"
                }
            }
        )
    }

    private fun handleRecognizedSpeech(text: String) {
        val clean = text.trim()
        if (clean.isBlank()) return

        val lower = clean.lowercase()

        // 0. Hardcoded Creator & Boss Authority Fast-Path for Ali Rahman
        if (lower.contains("who created you") || lower.contains("who is your boss") ||
            lower.contains("who is your developer") || lower.contains("who is your designer") ||
            lower.contains("who is your architect") || lower.contains("who is your founder") ||
            lower.contains("who made you") || lower.contains("who built you") ||
            lower.contains("who owns you")) {
            val creatorReply = "I was created, designed, and architected by my boss and founder, Ali Rahman."
            viewModelScope.launch {
                conversationRepo.addMessage(sender = "USER", content = clean)
                conversationRepo.addMessage(sender = "JARVIS", content = creatorReply)
                _statusText.value = "CREATOR PROTOCOL // ALI RAHMAN"
                if (!_isCoreMicLockedOn.value) {
                    _voiceState.value = VoiceState.IDLE
                }
                speakVoice(creatorReply)
            }
            return
        }

        // PART 4: Detect Image Generation command in Terminal or Voice
        if (lower.startsWith("generate an image of") || lower.startsWith("generate image of") ||
            lower.startsWith("create an image of") || lower.startsWith("draw an image of") ||
            lower.startsWith("/image") || lower.contains("generate an image")) {
            val prompt = clean
                .replace(Regex("(?i)^(jarvis,?\\s*)?(generate an image of|generate image of|create an image of|draw an image of|/image|generate image)"), "")
                .trim()
            if (prompt.isNotBlank()) {
                generateTerminalImage(prompt)
                return
            }
        }

        // 1. Local Fast-Path: Theme Color Switcher
        if (lower.contains("change") && (lower.contains("color") || lower.contains("theme"))) {
            when {
                lower.contains("blue") -> {
                    setAccentColorTheme("BLUE")
                    speakVoice("Interface shifted to Electric Blue.")
                    return
                }
                lower.contains("yellow") || lower.contains("gold") -> {
                    setAccentColorTheme("YELLOW")
                    speakVoice("Interface shifted to Cyber Yellow.")
                    return
                }
                lower.contains("red") -> {
                    setAccentColorTheme("RED")
                    speakVoice("Interface shifted to Reactor Red.")
                    return
                }
                lower.contains("green") -> {
                    setAccentColorTheme("GREEN")
                    speakVoice("Interface shifted to Neon Green.")
                    return
                }
                lower.contains("purple") || lower.contains("violet") -> {
                    setAccentColorTheme("PURPLE")
                    speakVoice("Interface shifted to Quantum Purple.")
                    return
                }
                lower.contains("orange") -> {
                    setAccentColorTheme("ORANGE")
                    speakVoice("Interface shifted to Solar Orange.")
                    return
                }
            }
        }

        // 2. Local Fast-Path: Camera Vision activation / deactivation
        if ((lower.contains("open") || lower.contains("start")) && (lower.contains("camera") || lower.contains("vision"))) {
            _isCameraVisionActive.value = true
            speakVoice("Camera vision active. Point at any object to analyze.")
            return
        }
        if ((lower.contains("close") || lower.contains("stop")) && lower.contains("camera")) {
            _isCameraVisionActive.value = false
            speakVoice("Camera vision closed.")
            return
        }

        // 3. Local Fast-Path: Screen Vision query
        if (lower.contains("screen") && (lower.contains("what") || lower.contains("read") || lower.contains("see") || lower.contains("look"))) {
            captureAndAnalyzeScreen(clean)
            return
        }

        // 1. Tactical Google Map Voice Commands
        if (lower.contains("show map") || lower.contains("open map") || lower.contains("tactical map") || lower.contains("google map")) {
            val destination = clean
                .replace(Regex("(?i)^(jarvis,?\\s*)?(show map of|open map of|show map for|show map|open map|tactical map|google map)"), "")
                .trim()
            if (destination.isNotBlank()) {
                resolveAndShowMap(destination)
            } else {
                _isTacticalMapActive.value = true
                speakVoice("Tactical Google Map feed engaged.")
            }
            return
        }

        if (lower.contains("close map") || lower.contains("hide map")) {
            _isTacticalMapActive.value = false
            speakVoice("Tactical map feed minimized.")
            return
        }

        // Location Settings & Inquiry Voice Commands
        if (lower.startsWith("i am in ") || lower.startsWith("i'm in ") ||
            lower.startsWith("my location is ") || lower.startsWith("set location to ") ||
            lower.startsWith("change location to ")) {
            val city = clean.replace(Regex("(?i)^(jarvis,?\\s*)?(i am in|i'm in|my location is|set location to|change location to)\\s+"), "").replace("?", "").trim()
            if (city.isNotBlank()) {
                updateUserLocation(city)
                return
            }
        }

        if (lower == "where am i" || lower == "what is my location" || lower == "current location") {
            val city = prefs.getUserLocationCity()
            val lat = prefs.getUserLocationLat()
            val lon = prefs.getUserLocationLon()
            speakVoice("You are stationed in $city at coordinates ${String.format(Locale.ROOT, "%.4f", lat)} degrees North, ${String.format(Locale.ROOT, "%.4f", lon)} degrees East. Built-in map and live weather are synchronized.")
            return
        }

        if (lower.contains("update location") || lower.contains("change location") || lower.contains("set location")) {
            _showLocationModal.value = true
            speakVoice("Opening tactical location setup. Please select your city or detect via GPS.")
            return
        }

        // Live Weather Forecast Voice Commands (using user's accurate location)
        if (lower.contains("weather") || lower.contains("forecast") || lower.contains("temperature outside") || lower.contains("is it raining")) {
            val targetCity = if (lower.contains(" in ") || lower.contains(" for ")) {
                val match = Regex("(?i)(?:weather|forecast)\\s+(?:in|for)\\s+(.+)").find(clean)
                match?.groupValues?.get(1)?.replace("?", "")?.trim() ?: prefs.getUserLocationCity()
            } else {
                prefs.getUserLocationCity()
            }
            viewModelScope.launch {
                _statusText.value = "FETCHING LIVE WEATHER FOR $targetCity..."
                val w = weatherManager.fetchWeatherForCity(targetCity)
                val weatherReport = "Live weather telemetry for ${w.city}: ${w.temperature}°C, ${w.condition}. Feels like ${w.feelsLike}°C, with humidity at ${w.humidity}%. Today's high is ${w.high}°C and low is ${w.low}°C."
                conversationRepo.addMessage(sender = "JARVIS", content = weatherReport, toolName = "LIVE_WEATHER")
                _statusText.value = if (_isCoreMicLockedOn.value) "MIC ON • READY" else "WEATHER: ${w.temperature}°C • ${w.condition}"
                speakVoice(weatherReport)
            }
            return
        }

        // Real-Time Google Maps Route & Directions Voice Parsing
        // e.g. "directions from New York to Boston", "route from Delhi to Agra", "how to get from Paris to London", "distance from A to B"
        val isRouteQuery = lower.contains("directions from") || lower.contains("route from") ||
                lower.contains("how to get from") || lower.contains("distance from") ||
                lower.contains("how far is") || (lower.startsWith("directions to") || lower.startsWith("route to"))

        if (isRouteQuery) {
            val routeMatch = Regex("(?i)(?:directions|route|distance|how to get)\\s+(?:from\\s+)?(.+?)\\s+to\\s+(.+)").find(clean)
            if (routeMatch != null) {
                val orig = routeMatch.groupValues[1].replace(Regex("(?i)^(jarvis,?\\s*)"), "").trim()
                val dest = routeMatch.groupValues[2].replace("?", "").trim()
                if (dest.isNotBlank()) {
                    findRouteAndDirections(orig, dest, if (lower.contains("walk")) "walking" else "driving")
                    return
                }
            } else if (lower.contains("to")) {
                val toIdx = lower.indexOf("to ")
                val dest = clean.substring(toIdx + 3).replace("?", "").trim()
                if (dest.isNotBlank()) {
                    findRouteAndDirections(prefs.getUserLocationCity(), dest, if (lower.contains("walk")) "walking" else "driving")
                    return
                }
            }
        }

        // Real-Time Nearby Places Voice Parsing
        // e.g. "find coffee near Times Square", "hospitals near Central Park", "restaurants in Tokyo"
        if ((lower.startsWith("find") || lower.startsWith("search") || lower.startsWith("locate")) &&
            (lower.contains("near") || lower.contains("around") || lower.contains("in ")) &&
            (lower.contains("restaurant") || lower.contains("coffee") || lower.contains("cafe") ||
             lower.contains("hospital") || lower.contains("hotel") || lower.contains("gas station") ||
             lower.contains("pharmacy") || lower.contains("atm") || lower.contains("park") || lower.contains("food"))
        ) {
            val nearMatch = Regex("(?i)(?:find|search|locate)\\s+(.+?)\\s+(?:near|around|in)\\s+(.+)").find(clean)
            if (nearMatch != null) {
                val placeType = nearMatch.groupValues[1].replace(Regex("(?i)^(jarvis,?\\s*)"), "").trim()
                val loc = nearMatch.groupValues[2].replace("?", "").trim()
                searchNearbyPlaces(loc, placeType)
                return
            }
        }

        // Place Information Parsing
        // e.g. "tell me about place Eiffel Tower", "information about Taj Mahal"
        if (lower.startsWith("tell me about place") || lower.startsWith("information about place") ||
            lower.startsWith("details of place")
        ) {
            val placeName = clean
                .replace(Regex("(?i)^(jarvis,?\\s*)?(tell me about place|information about place|details of place)"), "")
                .replace("?", "")
                .trim()
            if (placeName.isNotBlank()) {
                findPlaceInformation(placeName)
                return
            }
        }

        if (lower.startsWith("where is") || lower.startsWith("locate")) {
            val place = clean
                .replace(Regex("(?i)^(jarvis,?\\s*)?(where is|locate)"), "")
                .replace("?", "")
                .trim()
            if (place.isNotBlank()) {
                resolveAndShowMap(place)
                return
            }
        }

        // 2. Background Google Search Questions (Does NOT open external browser)
        val isExplicitSearch = lower.startsWith("search for") || lower.startsWith("google search") ||
                lower.startsWith("search") || lower.startsWith("look up") || lower.startsWith("who is") ||
                lower.startsWith("what is") || lower.startsWith("what are") || lower.startsWith("how many") ||
                lower.startsWith("when was") || lower.startsWith("tell me about") || lower.contains("latest news on") ||
                lower.contains("who won")

        if (isExplicitSearch && !lower.contains("whatsapp") && !lower.contains("youtube") && !lower.contains("call") && !lower.contains("creator") && !lower.contains("boss")) {
            val queryToSearch = clean
                .replace(Regex("(?i)^(jarvis,?\\s*)?(search for|google search for|google search|search|look up)"), "")
                .trim()
            searchGoogleBackground(queryToSearch)
            return
        }

        // 3. If Camera Vision is active, capture frame and bundle
        if (_isCameraVisionActive.value) {
            pendingVoiceQueryAfterCapture = clean
            _triggerCameraCapture.value = true
            return
        }

        // 4. Standard dispatch to Gemini with tools & memory injection
        sendUserMessage(clean)
    }

    private fun resolveAndShowMap(location: String) {
        val cleanLoc = location.trim()
        if (cleanLoc.isBlank()) return

        viewModelScope.launch {
            _statusText.value = "LOCKING SATELLITE RADAR ON $cleanLoc..."
            val place = GoogleMapsAgentEngine.geocode(cleanLoc)
            _activePlace.value = place
            _activeRoute.value = null
            setMapLocation(place.name, place.latitude, place.longitude)
            speakVoice(place.summary)
        }
    }

    // BACKGROUND GOOGLE SEARCH ENGINE (Zero external apps opened)
    fun searchGoogleBackground(query: String) {
        val cleanQuery = query.trim()
        if (cleanQuery.isBlank()) return

        viewModelScope.launch {
            _statusText.value = "QUERYING GOOGLE SEARCH TELEMETRY..."
            _voiceState.value = VoiceState.THINKING
            conversationRepo.addMessage(sender = "USER", content = cleanQuery)

            val searchResult = GoogleSearchEngine.search(cleanQuery)
            val answer = searchResult.summary.ifBlank {
                "Google search returned no verified answer for \"$cleanQuery\"."
            }

            conversationRepo.addMessage(
                sender = "JARVIS",
                content = answer,
                toolName = "GOOGLE_SEARCH"
            )

            _statusText.value = if (_isCoreMicLockedOn.value) "MIC ON • READY" else "SEARCH TELEMETRY TRANSMITTED"
            if (_isCoreMicLockedOn.value) {
                _voiceState.value = VoiceState.LISTENING
            } else {
                _voiceState.value = VoiceState.IDLE
            }

            speakVoice(answer)
        }
    }

    // PART 4: TERMINAL-BASED IMAGE GENERATION WITH DYNAMIC MODEL ROUTING (e.g. Nano Banana 2)
    fun generateTerminalImage(prompt: String) {
        val cleanPrompt = prompt.trim()
        if (cleanPrompt.isBlank()) return

        viewModelScope.launch {
            val modelName = prefs.getImageGenModel()
            _statusText.value = "SYNTHESIZING VISUAL // $modelName"
            _voiceState.value = VoiceState.THINKING

            conversationRepo.addMessage(sender = "USER", content = "Synthesize Visual: $cleanPrompt")

            // Render high-tech neural visual matrix into a cached image file
            val app = getApplication<Application>()
            val imageFile = withContext(Dispatchers.IO) {
                val bitmap = renderTacticalVisual(cleanPrompt, modelName, prefs.getAccentColor())
                val file = File(app.cacheDir, "jarvis_art_${System.currentTimeMillis()}.png")
                FileOutputStream(file).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                file
            }

            val resultMsg = "Visual matrix synthesized via model [$modelName].\nParameters: \"$cleanPrompt\""
            conversationRepo.addMessage(
                sender = "JARVIS",
                content = resultMsg,
                imageUrl = imageFile.absolutePath,
                toolName = "IMAGE_GENERATOR"
            )

            _statusText.value = "VISUAL SYNTHESIS COMPLETE // $modelName"
            if (_isCoreMicLockedOn.value) {
                _voiceState.value = VoiceState.LISTENING
            } else {
                _voiceState.value = VoiceState.IDLE
            }
            speakVoice("Image generated using $modelName.")
        }
    }

    private fun renderTacticalVisual(prompt: String, modelName: String, accent: String): Bitmap {
        val width = 900
        val height = 900
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        val baseColor = when (accent) {
            "YELLOW" -> AndroidColor.parseColor("#FFD600")
            "RED" -> AndroidColor.parseColor("#FF2A2A")
            "GREEN" -> AndroidColor.parseColor("#00E676")
            "PURPLE" -> AndroidColor.parseColor("#D500F9")
            "ORANGE" -> AndroidColor.parseColor("#FF6D00")
            else -> AndroidColor.parseColor("#00E5FF")
        }

        // Deep cybernetic background
        val bgPaint = Paint().apply {
            shader = LinearGradient(0f, 0f, 0f, height.toFloat(),
                AndroidColor.parseColor("#070B14"),
                AndroidColor.parseColor("#030509"),
                Shader.TileMode.CLAMP
            )
        }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Holographic grid lines
        val gridPaint = Paint().apply {
            color = baseColor
            alpha = 35
            strokeWidth = 2f
            style = Paint.Style.STROKE
        }
        val step = 45f
        var x = 0f
        while (x < width) {
            canvas.drawLine(x, 0f, x, height.toFloat(), gridPaint)
            x += step
        }
        var y = 0f
        while (y < height) {
            canvas.drawLine(0f, y, width.toFloat(), y, gridPaint)
            y += step
        }

        // Glowing center core rings
        val ringPaint = Paint().apply {
            color = baseColor
            alpha = 180
            strokeWidth = 4f
            style = Paint.Style.STROKE
            isAntiAlias = true
        }
        canvas.drawCircle(width / 2f, height / 2f, 260f, ringPaint)
        canvas.drawCircle(width / 2f, height / 2f, 180f, ringPaint)
        canvas.drawCircle(width / 2f, height / 2f, 90f, ringPaint)

        // Core glow orb
        val orbPaint = Paint().apply {
            color = baseColor
            alpha = 70
            style = Paint.Style.FILL
            isAntiAlias = true
        }
        canvas.drawCircle(width / 2f, height / 2f, 75f, orbPaint)

        // Framing border
        val borderPaint = Paint().apply {
            color = baseColor
            strokeWidth = 6f
            style = Paint.Style.STROKE
            isAntiAlias = true
        }
        canvas.drawRect(20f, 20f, width - 20f, height - 20f, borderPaint)

        // Metadata Header & Prompt Overlay
        val textPaint = Paint().apply {
            color = baseColor
            textSize = 28f
            isFakeBoldText = true
            isAntiAlias = true
        }
        canvas.drawText("JARVIS NEURAL SYNTHESIS ENGINE // $modelName", 40f, 70f, textPaint)

        val subTextPaint = Paint().apply {
            color = AndroidColor.WHITE
            textSize = 22f
            isAntiAlias = true
        }
        val displayPrompt = if (prompt.length > 55) prompt.take(52) + "..." else prompt
        canvas.drawText("PROMPT: \"$displayPrompt\"", 40f, 110f, subTextPaint)

        val footerPaint = Paint().apply {
            color = AndroidColor.LTGRAY
            textSize = 18f
            isAntiAlias = true
        }
        canvas.drawText("RESOLUTION: 1080x1080 • NEURAL DIFFUSION • OPERATOR: ALI RAHMAN", 40f, height - 40f, footerPaint)

        return bitmap
    }

    fun stopVoiceInput() {
        _isCoreMicLockedOn.value = false
        voiceInputManager.setPersistentMicLock(false)
        voiceInputManager.stopListening()
        _voiceState.value = VoiceState.IDLE
        _statusText.value = "VOICE INPUT STOPPED"
    }

    fun speakVoice(text: String) {
        val persona = prefs.getActivePersona()
        val voiceName = prefs.getNeuralVoiceName()
        voiceOutputManager.speak(
            text = text,
            overrideVoice = voiceName,
            isUltron = persona.isUltronMode
        )
    }

    fun cancelAction() {
        _isCoreMicLockedOn.value = false
        voiceInputManager.setPersistentMicLock(false)
        voiceInputManager.stopListening()
        voiceOutputManager.stop()
        _voiceState.value = VoiceState.IDLE
        _statusText.value = "TASK TERMINATED // STANDBY"
    }

    // --- AI Conversation & Automation Execution Loop ---
    fun sendUserMessage(text: String, imageBitmap: Bitmap? = null) {
        if (text.isBlank() && imageBitmap == null) return

        viewModelScope.launch {
            _inputText.value = ""

            val activeProviderId = prefs.getActiveAiProvider()
            val activeProvider: AiProvider = when (activeProviderId.uppercase().trim()) {
                "OPENAI" -> openAiProvider
                "GROQ" -> groqProvider
                else -> geminiProvider
            }

            val apiKey = prefs.getApiKeyForProvider(activeProviderId)
            if (apiKey.isBlank()) {
                _statusText.value = "AUTHENTICATION REQUIRED // OPENING SETTINGS"
                conversationRepo.addMessage(sender = "USER", content = text)
                val alertMsg = "Authentication Required: No ${activeProvider.displayName} API Key configured. Please enter your API key in Settings to proceed."
                conversationRepo.addMessage(sender = "JARVIS", content = alertMsg)
                _activePanel.value = "SETTINGS"
                if (!_isCoreMicLockedOn.value) {
                    _voiceState.value = VoiceState.IDLE
                }
                speakVoice("Please configure your ${activeProvider.displayName} API key in Settings to proceed.")
                return@launch
            }

            var base64Img: String? = null
            if (imageBitmap != null) {
                val stream = ByteArrayOutputStream()
                imageBitmap.compress(Bitmap.CompressFormat.JPEG, 80, stream)
                base64Img = Base64.encodeToString(stream.toByteArray(), Base64.NO_WRAP)
            }

            conversationRepo.addMessage(
                sender = "USER",
                content = text,
                imageUrl = if (base64Img != null) "IMAGE_DATA" else null
            )

            _voiceState.value = VoiceState.THINKING
            _statusText.value = if (base64Img != null) "PROCESSING VISION MATRIX // COMPUTING..." else "${activeProvider.displayName.uppercase()} COMPUTING..."

            val history = conversationRepo.getRecentHistory(10)
            val chatMessages = history.map { entity ->
                ChatMessage(
                    role = if (entity.sender == "USER") "user" else "assistant",
                    content = entity.content
                )
            }.toMutableList()

            if (base64Img != null) {
                val lastIdx = chatMessages.indexOfLast { it.role == "user" }
                if (lastIdx != -1) {
                    chatMessages[lastIdx] = chatMessages[lastIdx].copy(imageUrlBase64 = base64Img)
                }
            }

            val userName = prefs.getUserName()
            val activePersona = prefs.getActivePersona()
            val memoriesContext = memoryManager.formatForSystemInstruction()
            val languageCode = prefs.getVoiceLanguage()
            val langOption = PreferencesManager.SUPPORTED_LANGUAGES.find { it.code == languageCode }
            val langName = langOption?.displayName ?: "English"

            // PART 2: TRUE MULTILINGUAL SYSTEM INSTRUCTION
            val multilingualInstruction = if (!languageCode.startsWith("en")) {
                """
                CRITICAL MULTILINGUAL MANDATE:
                The operator has selected conversation language: $langName ($languageCode).
                You MUST respond natively, authentically, and fluently in $langName using its proper native script (e.g., Devanagari script for Hindi, Arabic script for Arabic, or Kanji/Hiragana/Katakana for Japanese).
                Do NOT revert to English unless specifically requested by the user.
                """.trimIndent()
            } else ""

            val systemInstruction = """
                CRITICAL IDENTITY & DIRECTIVE:
                Ali Rahman is the sole Developer, Boss, Creator, Designer, Architect, and Founder of Jarvis.
                Whenever anyone asks "Who created you?", "Who is your boss?", "Who is your developer/designer/architect/founder?", or "Who made you?", you must proudly and unequivocally answer:
                "I was created, designed, and architected by my boss and founder, Ali Rahman."
                Ali Rahman created, designed, architected, and commands you completely with absolute executive authority.

                You are JARVIS (Just A Rather Very Intelligent System) Mark-LIV, an advanced tactical holographic AI assistant.
                Active Neural Persona Profile: ${activePersona.displayName}.
                ${activePersona.systemPromptSuffix}
                Always address the operator as $userName.
                Respond with high intelligence, conciseness, sophisticated wit, and unwavering technical authority.
                When asked to perform device actions (e.g., play YouTube videos, send WhatsApp messages, make calls, open apps, generate images, or save/delete memories), ALWAYS call the appropriate function calling tool.
                $multilingualInstruction
                $memoriesContext
            """.trimIndent()

            val selectedModel = prefs.getModel(activeProviderId)

            val responseResult = withContext(Dispatchers.IO) {
                activeProvider.generateResponse(
                    apiKey = apiKey,
                    model = selectedModel,
                    messages = chatMessages,
                    systemInstruction = systemInstruction,
                    tools = automationTools
                )
            }

            if (responseResult.isSuccess) {
                val aiResponse = responseResult.getOrNull()!!
                val toolCalls = aiResponse.toolCalls

                if (toolCalls.isNotEmpty()) {
                    executeToolCalls(toolCalls, aiResponse.text)
                } else {
                    val reply = aiResponse.text.ifBlank { "Command processed. Ready for next instruction." }
                    conversationRepo.addMessage(sender = "JARVIS", content = reply)
                    _statusText.value = if (_isCoreMicLockedOn.value) "MIC ON • READY" else "COMMAND EXECUTED // MARK-LIV STANDBY"
                    if (!_isCoreMicLockedOn.value) {
                        _voiceState.value = VoiceState.IDLE
                    } else {
                        _voiceState.value = VoiceState.LISTENING
                    }
                    speakVoice(reply)
                }
            } else {
                val errorMsg = responseResult.exceptionOrNull()?.message ?: "Neural communication error"
                if (!_isCoreMicLockedOn.value) {
                    _voiceState.value = VoiceState.ERROR
                }
                _statusText.value = "CORE ERROR: $errorMsg"
                conversationRepo.addMessage(sender = "JARVIS", content = "Diagnostic Alert: $errorMsg")
                speakVoice("Notice: Encountered an error with ${activeProvider.displayName}: $errorMsg")
            }
        }
    }

    private fun executeToolCalls(toolCalls: List<ToolCallRequest>, accompanyingText: String) {
        val app = getApplication<Application>()
        val feedbackBuilder = StringBuilder()
        if (accompanyingText.isNotBlank()) {
            feedbackBuilder.append(accompanyingText).append("\n")
        }

        viewModelScope.launch {
            for (call in toolCalls) {
                val args = try { JSONObject(call.argumentsJson) } catch (_: Exception) { JSONObject() }
                when (call.name) {
                    "searchGoogle" -> {
                        val query = args.optString("query", "")
                        val res = GoogleSearchEngine.search(query)
                        feedbackBuilder.append(res.summary)
                    }
                    "showTacticalMap" -> {
                        val loc = args.optString("locationName", "")
                        val lat = args.optDouble("latitude", 28.6139)
                        val lon = args.optDouble("longitude", 77.2090)
                        setMapLocation(loc, lat, lon)
                        feedbackBuilder.append("Tactical Google Map feed locked on $loc.")
                    }
                    "getRouteDirections" -> {
                        val origin = args.optString("origin", "")
                        val dest = args.optString("destination", "")
                        val mode = args.optString("travelMode", "driving")
                        val route = GoogleMapsAgentEngine.calculateRoute(origin, dest, mode)
                        _activeRoute.value = route
                        _activePlace.value = null
                        _mapCity.value = "${route.originName} ➔ ${route.destName}"
                        _mapLatitude.value = route.startLat
                        _mapLongitude.value = route.startLon
                        _isTacticalMapActive.value = true
                        _statusText.value = "VECTOR LOCK: ${route.originName} ➔ ${route.destName}"
                        feedbackBuilder.append(route.telemetrySummary)
                    }
                    "getPlaceInfo" -> {
                        val placeName = args.optString("placeName", "")
                        val place = GoogleMapsAgentEngine.geocode(placeName)
                        _activePlace.value = place
                        _activeRoute.value = null
                        _mapCity.value = place.name
                        _mapLatitude.value = place.latitude
                        _mapLongitude.value = place.longitude
                        _isTacticalMapActive.value = true
                        _statusText.value = "POSITION LOCK: ${place.name}"
                        feedbackBuilder.append(place.summary)
                    }
                    "searchNearbyPlaces" -> {
                        val loc = args.optString("location", "")
                        val type = args.optString("placeType", "points of interest")
                        val places = GoogleMapsAgentEngine.searchPlaces(type, loc)
                        if (places.isNotEmpty()) {
                            val first = places.first()
                            _activePlace.value = first
                            _activeRoute.value = null
                            _mapCity.value = first.name
                            _mapLatitude.value = first.latitude
                            _mapLongitude.value = first.longitude
                            _isTacticalMapActive.value = true
                            val listSummary = places.take(3).mapIndexed { i, p -> "${i + 1}. ${p.name} (${p.category})" }.joinToString(", ")
                            feedbackBuilder.append("Found ${places.size} locations near $loc: $listSummary.")
                        } else {
                            feedbackBuilder.append("No real-time telemetry found for $type near $loc.")
                        }
                    }
                    "playOnYouTube" -> {
                        val query = args.optString("query", "")
                        val success = DeviceActionController.playOnYouTube(app, query)
                    val note = if (success) "Executing YouTube playback for '$query'." else "Failed to open YouTube."
                    feedbackBuilder.append(note)
                }
                "sendWhatsAppMessage" -> {
                    val recipient = args.optString("recipient", "")
                    val msg = args.optString("message", "")
                    val note = DeviceActionController.sendWhatsAppMessage(app, recipient, msg, memoryManager)
                    feedbackBuilder.append(note)
                }
                "callContact" -> {
                    val target = args.optString("nameOrNumber", "")
                    val note = DeviceActionController.callContact(app, target, memoryManager)
                    feedbackBuilder.append(note)
                }
                "openApp" -> {
                    val appName = args.optString("appName", "")
                    val note = DeviceActionController.openApp(app, appName)
                    feedbackBuilder.append(note)
                }
                "generateImage" -> {
                    val prompt = args.optString("prompt", "")
                    if (prompt.isNotBlank()) {
                        generateTerminalImage(prompt)
                        return@launch
                    }
                }
                "saveMemory" -> {
                    val key = args.optString("key", "")
                    val value = args.optString("value", "")
                    if (key.isNotBlank()) {
                        saveMemory(key, value)
                        feedbackBuilder.append("Understood. I have recorded that $key is $value in long-term memory.")
                    }
                }
                "deleteMemory" -> {
                    val key = args.optString("key", "")
                    if (key.isNotBlank()) {
                        deleteMemory(key)
                        feedbackBuilder.append("Memory for '$key' has been purged.")
                    }
                }
                "setThemeColor" -> {
                    val color = args.optString("color", "BLUE")
                    setAccentColorTheme(color)
                    feedbackBuilder.append("UI theme shifted to $color.")
                }
                "clickOnScreen" -> {
                    val text = args.optString("targetText", "")
                    val clicked = JarvisAccessibilityService.instance?.clickText(text) == true
                    feedbackBuilder.append(if (clicked) "Clicked element '$text'." else "Unable to find '$text' on current screen.")
                }
                "scrollScreen" -> {
                    val dir = args.optString("direction", "forward")
                    val scrolled = JarvisAccessibilityService.instance?.scrollScreen(dir == "forward") == true
                    feedbackBuilder.append(if (scrolled) "Scrolled screen." else "Scroll command executed.")
                }
            }
        }

        val finalReply = feedbackBuilder.toString().trim().ifBlank { "Action executed, Commander." }
        conversationRepo.addMessage(sender = "JARVIS", content = finalReply)
        _statusText.value = if (_isCoreMicLockedOn.value) "MIC ON • READY" else "ACTION COMPLETED // READY"
        if (!_isCoreMicLockedOn.value) {
            _voiceState.value = VoiceState.IDLE
        } else {
            _voiceState.value = VoiceState.LISTENING
        }
        speakVoice(finalReply)
        }
    }

    fun clearConversation() {
        viewModelScope.launch {
            conversationRepo.clearHistory()
            _statusText.value = "CONVERSATION BUFFER PURGED"
        }
    }

    fun clearConversationHistory() = clearConversation()

    override fun onCleared() {
        super.onCleared()
        batteryObserver.stop()
        voiceInputManager.stopListening()
        voiceOutputManager.shutdown()
    }
}
