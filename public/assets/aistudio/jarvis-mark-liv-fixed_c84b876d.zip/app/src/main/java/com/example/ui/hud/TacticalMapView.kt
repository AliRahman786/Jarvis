package com.example.ui.hud

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Route
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.maps.PlaceLocation
import com.example.maps.RouteCalculation
import com.example.ui.theme.AlertCrimson
import com.example.ui.theme.DarkHologramSurface
import com.example.ui.theme.HologramTextBright
import com.example.ui.theme.HologramTextDim
import com.example.ui.theme.HologramTextMuted
import com.example.ui.theme.ReactorCyanGlow
import com.example.ui.theme.SuccessEmerald
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.model.CameraPosition
import com.google.android.gms.maps.model.LatLng
import com.google.maps.android.compose.GoogleMap
import com.google.maps.android.compose.MapProperties
import com.google.maps.android.compose.MapType
import com.google.maps.android.compose.MapUiSettings
import com.google.maps.android.compose.Marker
import com.google.maps.android.compose.Polyline
import com.google.maps.android.compose.rememberCameraPositionState
import com.google.maps.android.compose.rememberMarkerState
import kotlinx.coroutines.launch

/**
 * Live Google Maps View integrated into JARVIS Tactical HUD.
 * Renders authentic Google Maps vector/satellite tiles, live position marker,
 * interactive zoom, panning, recenter, layer switching, and route telemetry overlays.
 */
@Composable
fun TacticalMapView(
    accentColor: Color,
    targetCity: String = "Global Defense Grid",
    latitude: Double = 28.6139,
    longitude: Double = 77.2090,
    routeCalculation: RouteCalculation? = null,
    placeLocation: PlaceLocation? = null,
    onClearRoute: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var isSatelliteGrid by remember { mutableStateOf(false) }
    var showStepsDrawer by remember { mutableStateOf(false) }

    val hasLocationPermission = remember(context) {
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
    }

    // Active coordinates
    val activeLat = placeLocation?.latitude ?: latitude
    val activeLon = placeLocation?.longitude ?: longitude
    val targetLatLng = remember(activeLat, activeLon) { LatLng(activeLat, activeLon) }

    val cameraPositionState = rememberCameraPositionState {
        position = CameraPosition.fromLatLngZoom(targetLatLng, 13.5f)
    }

    // Smoothly animate camera when target coordinates change
    LaunchedEffect(activeLat, activeLon) {
        cameraPositionState.animate(
            CameraUpdateFactory.newLatLngZoom(targetLatLng, 13.5f),
            durationMs = 900
        )
    }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(310.dp)
            .clip(RoundedCornerShape(14.dp))
            .background(DarkHologramSurface)
            .border(1.5.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(14.dp))
            .testTag("tactical_map_view")
    ) {
        // --- 1. REAL LIVE GOOGLE MAP ---
        GoogleMap(
            modifier = Modifier.fillMaxSize(),
            cameraPositionState = cameraPositionState,
            properties = MapProperties(
                mapType = if (isSatelliteGrid) MapType.HYBRID else MapType.NORMAL,
                isMyLocationEnabled = hasLocationPermission
            ),
            uiSettings = MapUiSettings(
                zoomControlsEnabled = false,
                myLocationButtonEnabled = false,
                compassEnabled = true,
                mapToolbarEnabled = false
            )
        ) {
            // Target Location Marker
            Marker(
                state = rememberMarkerState(position = targetLatLng),
                title = placeLocation?.name ?: targetCity,
                snippet = "${String.format("%.4f", activeLat)}°N, ${String.format("%.4f", activeLon)}°E"
            )

            // Real-time Road Route Polyline if route is active
            if (routeCalculation != null && routeCalculation.polylineCoords.isNotEmpty()) {
                val polyPoints = remember(routeCalculation) {
                    routeCalculation.polylineCoords.map { LatLng(it.first, it.second) }
                }
                Polyline(
                    points = polyPoints,
                    color = accentColor,
                    width = 10f
                )

                // Origin Marker
                Marker(
                    state = rememberMarkerState(
                        position = LatLng(routeCalculation.startLat, routeCalculation.startLon)
                    ),
                    title = "Origin: ${routeCalculation.originName}"
                )

                // Destination Marker
                Marker(
                    state = rememberMarkerState(
                        position = LatLng(routeCalculation.endLat, routeCalculation.endLon)
                    ),
                    title = "Destination: ${routeCalculation.destName}"
                )
            }
        }

        // --- 2. TACTICAL HUD TOP TELEMETRY BAR ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.TopCenter)
                .background(Color.Black.copy(alpha = 0.75f))
                .padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (hasLocationPermission) SuccessEmerald else accentColor)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = if (routeCalculation != null) {
                            "NAV // ${routeCalculation.originName} ➔ ${routeCalculation.destName}"
                        } else {
                            "SECTOR // ${placeLocation?.name ?: targetCity}".uppercase()
                        },
                        color = HologramTextBright,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1
                    )
                    Text(
                        text = if (routeCalculation != null) {
                            "${routeCalculation.distanceText} • ETA ${routeCalculation.durationText} (${routeCalculation.mode})"
                        } else {
                            "LAT: ${String.format("%.4f", activeLat)}° | LON: ${String.format("%.4f", activeLon)}°"
                        },
                        color = accentColor,
                        fontSize = 8.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (routeCalculation != null) {
                    // Turn-by-Turn Steps Toggle
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(accentColor.copy(alpha = 0.2f))
                            .clickable { showStepsDrawer = !showStepsDrawer }
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Route,
                                contentDescription = "Steps",
                                tint = accentColor,
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "STEPS",
                                color = accentColor,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Launch External Navigation
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(SuccessEmerald.copy(alpha = 0.25f))
                            .clickable { launchNativeGps(context, routeCalculation) }
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Navigation,
                                contentDescription = "Navigate",
                                tint = SuccessEmerald,
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "START",
                                color = SuccessEmerald,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Clear Route
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(AlertCrimson.copy(alpha = 0.2f))
                            .clickable(onClick = onClearRoute)
                            .padding(horizontal = 5.dp, vertical = 3.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear",
                            tint = AlertCrimson,
                            modifier = Modifier.size(11.dp)
                        )
                    }
                } else {
                    // Open in Google Maps External Button
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .background(accentColor.copy(alpha = 0.18f))
                            .clickable {
                                openInGoogleMapsApp(context, activeLat, activeLon, targetCity)
                            }
                            .padding(horizontal = 6.dp, vertical = 3.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Map,
                                contentDescription = "Open External",
                                tint = accentColor,
                                modifier = Modifier.size(11.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = "OPEN MAPS",
                                color = accentColor,
                                fontSize = 8.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // --- 3. TURN-BY-TURN ROUTE STEPS DRAWER OVERLAY ---
        AnimatedVisibility(
            visible = showStepsDrawer && routeCalculation != null,
            modifier = Modifier
                .fillMaxWidth(0.85f)
                .align(Alignment.CenterStart)
                .padding(start = 8.dp, top = 40.dp, bottom = 32.dp)
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.Black.copy(alpha = 0.92f))
                    .border(1.dp, accentColor, RoundedCornerShape(8.dp))
                    .padding(8.dp)
            ) {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TURN-BY-TURN TELEMETRY",
                            color = accentColor,
                            fontSize = 9.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close Steps",
                            tint = HologramTextDim,
                            modifier = Modifier
                                .size(14.dp)
                                .clickable { showStepsDrawer = false }
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyColumn(
                        modifier = Modifier.heightIn(max = 180.dp),
                        verticalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        itemsIndexed(routeCalculation!!.steps) { idx, step ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(accentColor.copy(alpha = 0.08f))
                                    .padding(horizontal = 6.dp, vertical = 3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "#${idx + 1}",
                                    color = accentColor,
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = step.instruction,
                                    color = HologramTextBright,
                                    fontSize = 8.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.weight(1f)
                                )
                                if (step.distanceText.isNotBlank()) {
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = step.distanceText,
                                        color = HologramTextDim,
                                        fontSize = 7.sp,
                                        fontFamily = FontFamily.Monospace
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // --- 4. TACTICAL HUD CONTROLS (Right Side Column) ---
        Column(
            modifier = Modifier
                .align(Alignment.CenterEnd)
                .padding(end = 8.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            // Zoom In (+)
            TacticalMapButton(
                icon = Icons.Default.Add,
                accentColor = accentColor,
                onClick = {
                    scope.launch {
                        cameraPositionState.animate(CameraUpdateFactory.zoomIn())
                    }
                }
            )

            // Zoom Out (-)
            TacticalMapButton(
                icon = Icons.Default.Remove,
                accentColor = accentColor,
                onClick = {
                    scope.launch {
                        cameraPositionState.animate(CameraUpdateFactory.zoomOut())
                    }
                }
            )

            // Recenter
            TacticalMapButton(
                icon = Icons.Default.GpsFixed,
                accentColor = accentColor,
                onClick = {
                    scope.launch {
                        cameraPositionState.animate(
                            CameraUpdateFactory.newLatLngZoom(targetLatLng, 14.5f),
                            durationMs = 600
                        )
                    }
                }
            )

            // Toggle Layer (Hybrid Satellite vs Normal)
            TacticalMapButton(
                icon = Icons.Default.Layers,
                accentColor = if (isSatelliteGrid) SuccessEmerald else accentColor,
                onClick = { isSatelliteGrid = !isSatelliteGrid }
            )
        }

        // --- 5. BOTTOM TELEMETRY BAR ---
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 8.dp, bottom = 6.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color.Black.copy(alpha = 0.8f))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
            Text(
                text = if (routeCalculation != null) {
                    "TACTICAL ROUTE: ACTIVE [TRANSIT: ${routeCalculation.mode.uppercase()} • ETA ${routeCalculation.durationText}]"
                } else {
                    "TELEMETRY: LOCK [${String.format("%.4f", activeLat)}°N, ${String.format("%.4f", activeLon)}°E]"
                },
                color = HologramTextMuted,
                fontSize = 8.sp,
                fontFamily = FontFamily.Monospace
            )
        }
    }
}

private fun launchNativeGps(context: Context, route: RouteCalculation) {
    try {
        val gmmIntent = Intent(Intent.ACTION_VIEW, Uri.parse(route.externalNavUri))
        gmmIntent.setPackage("com.google.android.apps.maps")
        context.startActivity(gmmIntent)
    } catch (_: Exception) {
        val webNav = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://www.google.com/maps/dir/?api=1&origin=${route.startLat},${route.startLon}&destination=${route.endLat},${route.endLon}")
        )
        context.startActivity(webNav)
    }
}

private fun openInGoogleMapsApp(context: Context, lat: Double, lon: Double, label: String) {
    try {
        val uri = Uri.parse("geo:$lat,$lon?q=$lat,$lon($label)")
        val mapIntent = Intent(Intent.ACTION_VIEW, uri)
        mapIntent.setPackage("com.google.android.apps.maps")
        context.startActivity(mapIntent)
    } catch (_: Exception) {
        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lon"))
        context.startActivity(webIntent)
    }
}

@Composable
private fun TacticalMapButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    accentColor: Color,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .size(32.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color.Black.copy(alpha = 0.85f))
            .border(1.dp, accentColor.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = "Map Control",
            tint = accentColor,
            modifier = Modifier.size(16.dp)
        )
    }
}
